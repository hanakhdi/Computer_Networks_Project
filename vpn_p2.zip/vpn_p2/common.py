from __future__ import annotations

import hashlib
import hmac
import ipaddress
import os
import re
import socket
import struct
import subprocess
import threading
import time
from dataclasses import dataclass
from enum import IntEnum
from typing import Callable

try:
    import fcntl
except ImportError:  # Lets protocol tests run on non-Linux development machines.
    fcntl = None


PROTOCOL_MAGIC = b"VPN1"
PROTOCOL_VERSION = 1
DEFAULT_PORT = 9000
DEFAULT_STATUS_PORT = 9200
DEFAULT_LB_PORT = 9100
DEFAULT_TUN_MTU = 1300
DEFAULT_PSK = "caesar-secret-key"

MAX_OUTER_FRAME = 2 * 1024 * 1024
MAX_REASSEMBLED_SIZE = 2 * 1024 * 1024
MAX_FRAGMENT_PAYLOAD = 1100
MAX_FRAGMENT_COUNT = 2048
MAX_CLIENT_ID_BYTES = 128
HEARTBEAT_INTERVAL = 5.0
HEARTBEAT_TIMEOUT = 15.0
FRAGMENT_TIMEOUT = 15.0

VPN_SUBNET = "10.8.0.0/24"
SERVER_TUN_IP_CIDR = "10.8.0.1/24"

TUNSETIFF = 0x400454CA
IFF_TUN = 0x0001
IFF_NO_PI = 0x1000

_LENGTH_STRUCT = struct.Struct("!I")
_HEADER_STRUCT = struct.Struct("!BBIIHHI")
_CLIENT_HELLO_STRUCT = struct.Struct("!4sB16sH")
_SERVER_RESPONSE_STRUCT = struct.Struct("!B16sB")
_SERVER_CHANNEL_RESPONSE_STRUCT = struct.Struct("!B16s")
_HMAC_SIZE = hashlib.sha256().digest_size
_MAX_MESSAGE_PAYLOAD = MAX_OUTER_FRAME - _HEADER_STRUCT.size


class FramingError(ValueError):
    pass


class AuthenticationError(RuntimeError):
    pass


class NetworkCommandError(RuntimeError):
    pass


class CaesarChannel:
    """Educational byte-shift channel; it is not production encryption."""

    def __init__(self, shift: int) -> None:
        self.shift = shift % 256

    def encrypt(self, data: bytes) -> bytes:
        return bytes((byte + self.shift) % 256 for byte in data)

    def decrypt(self, data: bytes) -> bytes:
        return bytes((byte - self.shift) % 256 for byte in data)


def recv_exact(sock: socket.socket, count: int) -> bytes:
    if count < 0:
        raise ValueError("count cannot be negative")
    data = bytearray()
    while len(data) < count:
        chunk = sock.recv(count - len(data))
        if not chunk:
            raise ConnectionError("connection closed during socket read")
        data.extend(chunk)
    return bytes(data)


def send_frame(sock: socket.socket, payload: bytes) -> None:
    if len(payload) > MAX_OUTER_FRAME:
        raise FramingError(f"frame is too large: {len(payload)} bytes")
    sock.sendall(_LENGTH_STRUCT.pack(len(payload)) + payload)


def recv_frame(sock: socket.socket) -> bytes:
    (length,) = _LENGTH_STRUCT.unpack(recv_exact(sock, _LENGTH_STRUCT.size))
    if length > MAX_OUTER_FRAME:
        raise FramingError(f"declared frame is too large: {length} bytes")
    return recv_exact(sock, length)


def recv_line(sock: socket.socket, max_bytes: int = 4096) -> bytes:
    data = bytearray()
    while len(data) <= max_bytes:
        chunk = sock.recv(min(1024, max_bytes + 1 - len(data)))
        if not chunk:
            break
        data.extend(chunk)
        newline = data.find(b"\n")
        if newline >= 0:
            return bytes(data[:newline])
    if len(data) > max_bytes:
        raise ValueError("line is too long")
    return bytes(data)


class MessageType(IntEnum):
    DATA = 1
    HEARTBEAT = 2
    HEARTBEAT_ACK = 3
    CLOSE = 4
    AUTH_REQUEST = 5
    AUTH_RESPONSE = 6
    QUOTA_EXHAUSTED = 7
    PROXY_CONNECT = 8
    PROXY_CONNECTED = 9
    PROXY_DATA = 10
    PROXY_CLOSE = 11


@dataclass(frozen=True)
class Message:
    msg_type: MessageType
    session_id: int
    packet_id: int
    fragment_index: int
    fragment_count: int
    payload: bytes

    def validate(self) -> None:
        if not 0 <= self.session_id <= 0xFFFFFFFF:
            raise ValueError("session ID is outside the 32-bit range")
        if not 0 <= self.packet_id <= 0xFFFFFFFF:
            raise ValueError("packet ID is outside the 32-bit range")
        if not 1 <= self.fragment_count <= MAX_FRAGMENT_COUNT:
            raise ValueError("invalid fragment count")
        if not 0 <= self.fragment_index < self.fragment_count:
            raise ValueError("invalid fragment index")
        if len(self.payload) > _MAX_MESSAGE_PAYLOAD:
            raise ValueError("message payload is too large")

    def encode(self) -> bytes:
        self.validate()
        header = _HEADER_STRUCT.pack(
            PROTOCOL_VERSION,
            int(self.msg_type),
            self.session_id,
            self.packet_id,
            self.fragment_index,
            self.fragment_count,
            len(self.payload),
        )
        return header + self.payload

    @classmethod
    def decode(cls, data: bytes) -> Message:
        if len(data) < _HEADER_STRUCT.size:
            raise ValueError("message is shorter than its header")
        (
            version,
            msg_type,
            session_id,
            packet_id,
            fragment_index,
            fragment_count,
            payload_length,
        ) = _HEADER_STRUCT.unpack(data[: _HEADER_STRUCT.size])
        if version != PROTOCOL_VERSION:
            raise ValueError(f"unsupported protocol version: {version}")
        if fragment_count == 0:
            raise ValueError("fragment count cannot be zero")
        if fragment_count > MAX_FRAGMENT_COUNT:
            raise ValueError("fragment count is unreasonably large")
        if fragment_index >= fragment_count:
            raise ValueError("fragment index is outside fragment count")
        actual_length = len(data) - _HEADER_STRUCT.size
        if payload_length != actual_length:
            raise ValueError(
                f"payload length mismatch: declared {payload_length}, received {actual_length}"
            )
        message = cls(
            msg_type=MessageType(msg_type),
            session_id=session_id,
            packet_id=packet_id,
            fragment_index=fragment_index,
            fragment_count=fragment_count,
            payload=data[_HEADER_STRUCT.size :],
        )
        message.validate()
        return message


def make_messages(
    msg_type: MessageType,
    payload: bytes = b"",
    session_id: int = 0,
    max_fragment_payload: int = MAX_FRAGMENT_PAYLOAD,
) -> list[Message]:
    if not 1 <= max_fragment_payload <= _MAX_MESSAGE_PAYLOAD:
        raise ValueError("invalid maximum fragment payload")
    if len(payload) > MAX_REASSEMBLED_SIZE:
        raise ValueError("payload exceeds the reassembly size limit")

    chunks = (
        [payload[index : index + max_fragment_payload] for index in range(0, len(payload), max_fragment_payload)]
        if payload
        else [b""]
    )
    if len(chunks) > MAX_FRAGMENT_COUNT:
        raise ValueError("payload requires too many fragments")

    packet_id = int.from_bytes(os.urandom(4), "big")
    return [
        Message(
            msg_type=msg_type,
            session_id=session_id,
            packet_id=packet_id,
            fragment_index=index,
            fragment_count=len(chunks),
            payload=chunk,
        )
        for index, chunk in enumerate(chunks)
    ]


class Reassembler:
    def __init__(
        self,
        timeout: float = FRAGMENT_TIMEOUT,
        max_size: int = MAX_REASSEMBLED_SIZE,
    ) -> None:
        self.timeout = timeout
        self.max_size = max_size
        self._items: dict[tuple[int, int, int], dict[str, object]] = {}
        self._completed: dict[tuple[int, int, int], float] = {}
        self._lock = threading.Lock()

    def add(self, message: Message) -> tuple[MessageType, int, bytes] | None:
        message.validate()
        now = time.monotonic()
        key = (int(message.msg_type), message.session_id, message.packet_id)

        with self._lock:
            self._expire_locked(now)
            if key in self._completed:
                return None

            item = self._items.get(key)
            if item is None:
                item = {
                    "created": now,
                    "count": message.fragment_count,
                    "parts": {},
                    "size": 0,
                }
                self._items[key] = item
            elif item["count"] != message.fragment_count:
                del self._items[key]
                raise ValueError("fragment count changed during reassembly")

            parts = item["parts"]
            assert isinstance(parts, dict)
            existing = parts.get(message.fragment_index)
            if existing is not None:
                if existing != message.payload:
                    del self._items[key]
                    raise ValueError("duplicate fragment has different data")
                return None

            new_size = int(item["size"]) + len(message.payload)
            if new_size > self.max_size:
                del self._items[key]
                raise ValueError("reassembled message exceeds size limit")
            parts[message.fragment_index] = message.payload
            item["size"] = new_size

            if len(parts) != int(item["count"]):
                return None

            payload = b"".join(parts[index] for index in range(int(item["count"])))
            del self._items[key]
            self._completed[key] = now
            return message.msg_type, message.session_id, payload

    def expire_stale(self, now: float | None = None) -> int:
        with self._lock:
            return self._expire_locked(time.monotonic() if now is None else now)

    def pending_count(self) -> int:
        with self._lock:
            return len(self._items)

    def _expire_locked(self, now: float) -> int:
        stale = [
            key
            for key, item in self._items.items()
            if now - float(item["created"]) > self.timeout
        ]
        for key in stale:
            del self._items[key]

        old_completed = [
            key
            for key, completed_at in self._completed.items()
            if now - completed_at > self.timeout
        ]
        for key in old_completed:
            del self._completed[key]
        return len(stale)


@dataclass(frozen=True)
class Flow:
    protocol: int
    source_ip: str
    source_port: int
    destination_ip: str
    destination_port: int

    @property
    def protocol_name(self) -> str:
        return {1: "ICMP", 6: "TCP", 17: "UDP"}.get(
            self.protocol, f"IP-{self.protocol}"
        )

    @property
    def session_id(self) -> int:
        five_tuple = (
            f"{self.protocol}|{self.source_ip}|{self.source_port}|"
            f"{self.destination_ip}|{self.destination_port}"
        ).encode("ascii")
        digest = hashlib.blake2s(
            five_tuple, digest_size=4, person=b"VPNFLOW"
        ).digest()
        return int.from_bytes(digest, "big")


def parse_ipv4(packet: bytes) -> Flow:
    if len(packet) < 20:
        raise ValueError("IPv4 packet is shorter than the minimum header")
    version = packet[0] >> 4
    ihl = (packet[0] & 0x0F) * 4
    if version != 4:
        raise ValueError("packet is not IPv4")
    if ihl < 20 or ihl > len(packet):
        raise ValueError("invalid or truncated IPv4 header length")

    (total_length,) = struct.unpack("!H", packet[2:4])
    if total_length < ihl or total_length > len(packet):
        raise ValueError("invalid or truncated IPv4 total length")

    protocol = packet[9]
    source_ip = str(ipaddress.IPv4Address(packet[12:16]))
    destination_ip_address = str(ipaddress.IPv4Address(packet[16:20]))
    source_port = destination_port = 0

    (fragment_field,) = struct.unpack("!H", packet[6:8])
    fragment_offset = fragment_field & 0x1FFF
    if protocol in (6, 17) and fragment_offset == 0:
        if total_length < ihl + 4:
            raise ValueError("TCP/UDP packet is missing its port fields")
        source_port, destination_port = struct.unpack(
            "!HH", packet[ihl : ihl + 4]
        )

    return Flow(
        protocol=protocol,
        source_ip=source_ip,
        source_port=source_port,
        destination_ip=destination_ip_address,
        destination_port=destination_port,
    )


def destination_ip(packet: bytes) -> str:
    return parse_ipv4(packet).destination_ip


def session_id_for_packet(packet: bytes) -> int:
    return parse_ipv4(packet).session_id


def _psk_bytes(psk: str) -> bytes:
    encoded = psk.encode("utf-8")
    if not encoded:
        raise ValueError("PSK cannot be empty")
    return encoded


def _mac(psk: bytes, label: bytes, body: bytes) -> bytes:
    return hmac.new(psk, label + body, hashlib.sha256).digest()


def _derive_shift(psk: bytes, client_nonce: bytes, server_nonce: bytes) -> int:
    digest = hashlib.sha256(
        b"vpn-phase1-caesar|" + psk + client_nonce + server_nonce
    ).digest()
    return 1 + (digest[0] % 255)


def _send_handshake_rejection(sock: socket.socket, reason: str) -> None:
    message = reason.encode("utf-8", errors="replace")[:200]
    try:
        send_frame(sock, b"\x00" + message)
    except OSError:
        pass


def client_channel_handshake(
    sock: socket.socket, client_id: str, psk: str
) -> CaesarChannel:
    """Authenticate the shared PSK and derive the Phase 1 channel cipher."""
    psk_bytes = _psk_bytes(psk)
    client_id_bytes = client_id.encode("utf-8")
    if not 1 <= len(client_id_bytes) <= MAX_CLIENT_ID_BYTES:
        raise ValueError("client ID must be 1 to 128 UTF-8 bytes")

    client_nonce = os.urandom(16)
    hello_body = _CLIENT_HELLO_STRUCT.pack(
        PROTOCOL_MAGIC,
        PROTOCOL_VERSION,
        client_nonce,
        len(client_id_bytes),
    ) + client_id_bytes
    send_frame(
        sock,
        hello_body + _mac(psk_bytes, b"client-hello|", hello_body),
    )

    response = recv_frame(sock)
    if not response:
        raise AuthenticationError("empty handshake response")
    if response[0] == 0:
        reason = response[1:].decode("utf-8", errors="replace")
        raise AuthenticationError(reason or "handshake rejected")
    expected_length = _SERVER_CHANNEL_RESPONSE_STRUCT.size + _HMAC_SIZE
    if len(response) != expected_length:
        raise AuthenticationError("malformed server channel response")

    status, server_nonce = _SERVER_CHANNEL_RESPONSE_STRUCT.unpack(
        response[: _SERVER_CHANNEL_RESPONSE_STRUCT.size]
    )
    if status != 1:
        raise AuthenticationError("server rejected channel establishment")
    response_body = response[:-_HMAC_SIZE]
    expected_mac = _mac(
        psk_bytes, b"server-channel|", client_nonce + response_body
    )
    if not hmac.compare_digest(response[-_HMAC_SIZE:], expected_mac):
        raise AuthenticationError("server PSK authentication failed")
    return CaesarChannel(_derive_shift(psk_bytes, client_nonce, server_nonce))


def server_channel_handshake(
    sock: socket.socket,
    psk: str,
    client_id_validator: Callable[[str], bool] | None = None,
) -> tuple[CaesarChannel, str]:
    """Complete the PSK layer without allocating a virtual IP."""
    psk_bytes = _psk_bytes(psk)
    try:
        hello = recv_frame(sock)
        minimum = _CLIENT_HELLO_STRUCT.size + _HMAC_SIZE
        if len(hello) < minimum:
            raise AuthenticationError("client handshake is too short")
        magic, version, client_nonce, client_id_length = _CLIENT_HELLO_STRUCT.unpack(
            hello[: _CLIENT_HELLO_STRUCT.size]
        )
        expected_length = _CLIENT_HELLO_STRUCT.size + client_id_length + _HMAC_SIZE
        if magic != PROTOCOL_MAGIC or version != PROTOCOL_VERSION:
            raise AuthenticationError("invalid protocol magic or version")
        if not 1 <= client_id_length <= MAX_CLIENT_ID_BYTES:
            raise AuthenticationError("invalid client ID length")
        if len(hello) != expected_length:
            raise AuthenticationError("malformed client handshake length")

        hello_body = hello[:-_HMAC_SIZE]
        if not hmac.compare_digest(
            hello[-_HMAC_SIZE:], _mac(psk_bytes, b"client-hello|", hello_body)
        ):
            raise AuthenticationError("client PSK authentication failed")
        try:
            client_id = hello[
                _CLIENT_HELLO_STRUCT.size : -_HMAC_SIZE
            ].decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AuthenticationError("client ID is not valid UTF-8") from exc
        if client_id_validator is not None and not client_id_validator(client_id):
            raise AuthenticationError("duplicate active client ID")

        server_nonce = os.urandom(16)
        response_body = _SERVER_CHANNEL_RESPONSE_STRUCT.pack(1, server_nonce)
        response_mac = _mac(
            psk_bytes, b"server-channel|", client_nonce + response_body
        )
        send_frame(sock, response_body + response_mac)
        return CaesarChannel(_derive_shift(psk_bytes, client_nonce, server_nonce)), client_id
    except AuthenticationError as exc:
        _send_handshake_rejection(sock, str(exc))
        raise
    except (UnicodeError, ValueError, struct.error) as exc:
        _send_handshake_rejection(sock, "malformed handshake")
        raise AuthenticationError("malformed handshake") from exc


def client_handshake(
    sock: socket.socket, client_id: str, psk: str
) -> tuple[CaesarChannel, str]:
    psk_bytes = _psk_bytes(psk)
    client_id_bytes = client_id.encode("utf-8")
    if not 1 <= len(client_id_bytes) <= MAX_CLIENT_ID_BYTES:
        raise ValueError("client ID must be 1 to 128 UTF-8 bytes")

    client_nonce = os.urandom(16)
    hello_body = _CLIENT_HELLO_STRUCT.pack(
        PROTOCOL_MAGIC,
        PROTOCOL_VERSION,
        client_nonce,
        len(client_id_bytes),
    ) + client_id_bytes
    send_frame(
        sock,
        hello_body + _mac(psk_bytes, b"client-hello|", hello_body),
    )

    response = recv_frame(sock)
    if not response:
        raise AuthenticationError("empty handshake response")
    if response[0] == 0:
        reason = response[1:].decode("utf-8", errors="replace")
        raise AuthenticationError(reason or "handshake rejected")
    if len(response) < _SERVER_RESPONSE_STRUCT.size + _HMAC_SIZE:
        raise AuthenticationError("server handshake response is too short")

    status, server_nonce, ip_length = _SERVER_RESPONSE_STRUCT.unpack(
        response[: _SERVER_RESPONSE_STRUCT.size]
    )
    expected_length = _SERVER_RESPONSE_STRUCT.size + ip_length + _HMAC_SIZE
    if status != 1 or ip_length == 0 or len(response) != expected_length:
        raise AuthenticationError("malformed server handshake response")

    response_body = response[:-_HMAC_SIZE]
    received_mac = response[-_HMAC_SIZE:]
    expected_mac = _mac(
        psk_bytes, b"server-response|", client_nonce + response_body
    )
    if not hmac.compare_digest(received_mac, expected_mac):
        raise AuthenticationError("server PSK authentication failed")

    virtual_ip_bytes = response[
        _SERVER_RESPONSE_STRUCT.size : -_HMAC_SIZE
    ]
    virtual_ip = str(ipaddress.IPv4Address(virtual_ip_bytes.decode("ascii")))
    return (
        CaesarChannel(_derive_shift(psk_bytes, client_nonce, server_nonce)),
        virtual_ip,
    )


def server_handshake(
    sock: socket.socket,
    assigned_ip: str,
    psk: str,
    client_id_validator: Callable[[str], bool] | None = None,
) -> tuple[CaesarChannel, str]:
    psk_bytes = _psk_bytes(psk)
    try:
        hello = recv_frame(sock)
        minimum = _CLIENT_HELLO_STRUCT.size + _HMAC_SIZE
        if len(hello) < minimum:
            raise AuthenticationError("client handshake is too short")

        magic, version, client_nonce, client_id_length = _CLIENT_HELLO_STRUCT.unpack(
            hello[: _CLIENT_HELLO_STRUCT.size]
        )
        expected_length = (
            _CLIENT_HELLO_STRUCT.size + client_id_length + _HMAC_SIZE
        )
        if magic != PROTOCOL_MAGIC or version != PROTOCOL_VERSION:
            raise AuthenticationError("invalid protocol magic or version")
        if not 1 <= client_id_length <= MAX_CLIENT_ID_BYTES:
            raise AuthenticationError("invalid client ID length")
        if len(hello) != expected_length:
            raise AuthenticationError("malformed client handshake length")

        hello_body = hello[:-_HMAC_SIZE]
        received_mac = hello[-_HMAC_SIZE:]
        expected_mac = _mac(psk_bytes, b"client-hello|", hello_body)
        if not hmac.compare_digest(received_mac, expected_mac):
            raise AuthenticationError("client PSK authentication failed")

        client_id_bytes = hello[
            _CLIENT_HELLO_STRUCT.size : -_HMAC_SIZE
        ]
        try:
            client_id = client_id_bytes.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AuthenticationError("client ID is not valid UTF-8") from exc
        if client_id_validator is not None and not client_id_validator(client_id):
            raise AuthenticationError("duplicate active client ID")

        virtual_ip = str(ipaddress.IPv4Address(assigned_ip))
        ip_bytes = virtual_ip.encode("ascii")
        server_nonce = os.urandom(16)
        response_body = _SERVER_RESPONSE_STRUCT.pack(
            1, server_nonce, len(ip_bytes)
        ) + ip_bytes
        response_mac = _mac(
            psk_bytes, b"server-response|", client_nonce + response_body
        )
        send_frame(sock, response_body + response_mac)
        return (
            CaesarChannel(_derive_shift(psk_bytes, client_nonce, server_nonce)),
            client_id,
        )
    except AuthenticationError as exc:
        _send_handshake_rejection(sock, str(exc))
        raise
    except (UnicodeError, ValueError, struct.error) as exc:
        _send_handshake_rejection(sock, "malformed handshake")
        raise AuthenticationError("malformed handshake") from exc


@dataclass
class TunDevice:
    fd: int
    name: str

    def close(self) -> None:
        if self.fd < 0:
            return
        fd, self.fd = self.fd, -1
        try:
            os.close(fd)
        except OSError:
            pass


def create_tun(requested_name: str = "tun0") -> TunDevice:
    if os.name != "posix" or fcntl is None:
        raise RuntimeError("TUN mode is supported only on Linux")
    try:
        fd = os.open("/dev/net/tun", os.O_RDWR)
    except OSError as exc:
        raise RuntimeError(
            "cannot open /dev/net/tun; run on Linux with TUN enabled and use sudo"
        ) from exc
    try:
        ifreq = struct.pack(
            "16sH",
            requested_name.encode("ascii"),
            IFF_TUN | IFF_NO_PI,
        )
        result = fcntl.ioctl(fd, TUNSETIFF, ifreq)
    except Exception:
        os.close(fd)
        raise
    actual_name = result[:16].split(b"\x00", 1)[0].decode("ascii")
    return TunDevice(fd, actual_name)


def run_network_command(
    args: list[str], check: bool = True
) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            args,
            check=False,
            text=True,
            capture_output=True,
        )
    except FileNotFoundError as exc:
        raise NetworkCommandError(
            f"network command not found: {args[0]}; install iproute2/iptables"
        ) from exc
    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or "unknown error"
        raise NetworkCommandError(
            f"{' '.join(args)} failed: {detail}. Run with sudo and verify Linux networking tools."
        )
    return result


def configure_tun(name: str, ip_cidr: str, mtu: int = DEFAULT_TUN_MTU) -> None:
    ipaddress.ip_interface(ip_cidr)
    if mtu < 576:
        raise ValueError("TUN MTU must be at least 576")
    run_network_command(["ip", "addr", "replace", ip_cidr, "dev", name])
    run_network_command(
        ["ip", "link", "set", "dev", name, "mtu", str(mtu)]
    )
    run_network_command(["ip", "link", "set", "dev", name, "up"])


class RouteManager:
    def __init__(self, tun_name: str) -> None:
        self.tun_name = tun_name
        self._added_routes: list[list[str]] = []

    def _route_exists(self, destination: str) -> bool:
        result = run_network_command(
            ["ip", "-4", "route", "show", destination], check=False
        )
        return bool(result.stdout.strip())

    def _add_route(self, route: list[str]) -> None:
        destination = route[0]
        if self._route_exists(destination):
            raise NetworkCommandError(
                f"route {destination} already exists; refusing to overwrite it"
            )
        run_network_command(["ip", "-4", "route", "add", *route])
        self._added_routes.append(route)

    def add_tunnel_route(self, destination: str) -> None:
        network = str(ipaddress.IPv4Network(destination, strict=False))
        self._add_route([network, "dev", self.tun_name])

    def enable_full_tunnel(self, server_ip: str) -> None:
        server_address = str(ipaddress.IPv4Address(server_ip))
        result = run_network_command(["ip", "-4", "route", "show", "default"])
        default_line = next(
            (line for line in result.stdout.splitlines() if line.strip()), ""
        )
        gateway_match = re.search(r"\bvia\s+(\S+)", default_line)
        device_match = re.search(r"\bdev\s+(\S+)", default_line)
        if not device_match:
            raise NetworkCommandError("could not determine the original default route")

        server_route = [f"{server_address}/32"]
        if gateway_match:
            server_route.extend(["via", gateway_match.group(1)])
        server_route.extend(["dev", device_match.group(1)])

        if not self._route_exists(server_route[0]):
            self._add_route(server_route)
        for network in ("0.0.0.0/1", "128.0.0.0/1"):
            self._add_route([network, "dev", self.tun_name])

    def cleanup(self) -> None:
        for route in reversed(self._added_routes):
            try:
                run_network_command(
                    ["ip", "-4", "route", "del", *route], check=False
                )
            except NetworkCommandError:
                pass
        self._added_routes.clear()
