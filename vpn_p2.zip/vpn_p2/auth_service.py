from __future__ import annotations

from dataclasses import dataclass

from database import Repository


@dataclass(frozen=True)
class AuthenticatedUser:
    id: int
    username: str
    quota_bytes: int
    used_bytes: int
    upload_rate_bps: int
    download_rate_bps: int


class AuthService:
    def __init__(self, repository: Repository) -> None:
        self.repository = repository

    def authenticate_vpn(
        self, username: str, password: str
    ) -> tuple[AuthenticatedUser | None, str]:
        row, reason = self.repository.authorize_vpn(username, password)
        if row is None:
            return None, reason
        return (
            AuthenticatedUser(
                id=int(row["id"]),
                username=str(row["username"]),
                quota_bytes=int(row["quota_bytes"]),
                used_bytes=int(row["used_bytes"]),
                upload_rate_bps=int(row["upload_rate_bps"]),
                download_rate_bps=int(row["download_rate_bps"]),
            ),
            "ok",
        )
