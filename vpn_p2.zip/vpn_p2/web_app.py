from __future__ import annotations

import hmac
import ipaddress
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Any, Callable, TypeVar, cast

from flask import (
    Flask,
    Response,
    abort,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)

from database import Repository
from rate_limiter import TokenBucket


COOKIE_NAME = "vpn_portal_token"
F = TypeVar("F", bound=Callable[..., Any])


def _future_iso(days: int = 0, hours: int = 0) -> str:
    return (datetime.now(timezone.utc) + timedelta(days=days, hours=hours)).isoformat(
        timespec="seconds"
    )


def create_app(vpn_server: Any, repository: Repository, secret: str) -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.update(SECRET_KEY=secret, MAX_CONTENT_LENGTH=64 * 1024)

    @app.template_filter("bytesfmt")
    def bytesfmt(value: object) -> str:
        amount = float(value or 0)
        for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
            if amount < 1024 or unit == "TiB":
                return f"{amount:.1f} {unit}"
            amount /= 1024
        return f"{amount:.1f} TiB"

    def csrf_for(token: str) -> str:
        return hmac.digest(secret.encode("utf-8"), token.encode("utf-8"), "sha256").hex()

    @app.before_request
    def load_identity() -> None:
        token = request.cookies.get(COOKIE_NAME, "")
        g.auth_token = token
        g.current_user = repository.validate_web_session(token) if token else None
        g.csrf_token = csrf_for(token) if token else ""
        if request.method == "POST" and request.endpoint not in {"login", "static"}:
            supplied = request.form.get("_csrf", "")
            if not token or not hmac.compare_digest(supplied, g.csrf_token):
                abort(400, "invalid CSRF token")

    def login_required(role: str | None = None) -> Callable[[F], F]:
        def decorate(function: F) -> F:
            @wraps(function)
            def wrapped(*args: object, **kwargs: object) -> object:
                if g.current_user is None:
                    return redirect(url_for("login"))
                if role is not None and g.current_user["role"] != role:
                    abort(403)
                return function(*args, **kwargs)

            return cast(F, wrapped)

        return decorate

    @app.context_processor
    def shared_context() -> dict[str, object]:
        return {
            "current_user": getattr(g, "current_user", None),
            "csrf_token": getattr(g, "csrf_token", ""),
        }

    @app.get("/")
    def index() -> Response:
        if g.current_user is None:
            return redirect(url_for("login"))
        return redirect(
            url_for("admin")
            if g.current_user["role"] == "admin"
            else url_for("portal")
        )

    @app.route("/login", methods=["GET", "POST"])
    def login() -> Response | str:
        if request.method == "GET":
            return render_template("login.html")
        user = repository.authenticate(
            request.form.get("username", ""), request.form.get("password", "")
        )
        if user is None:
            flash("Invalid username or password.", "error")
            return render_template("login.html"), 401
        remember = request.form.get("remember") == "yes"
        lifetime = timedelta(days=30) if remember else timedelta(hours=24)
        expires_at = (
            datetime.now(timezone.utc) + lifetime
        ).isoformat(timespec="seconds")
        token = repository.create_web_session(int(user["id"]), expires_at)
        response = redirect(
            url_for("admin") if user["role"] == "admin" else url_for("portal")
        )
        response.set_cookie(
            COOKIE_NAME,
            token,
            max_age=int(lifetime.total_seconds()),
            httponly=True,
            samesite="Lax",
            secure=request.is_secure,
        )
        return response

    @app.post("/logout")
    @login_required()
    def logout() -> Response:
        repository.revoke_web_session(g.auth_token)
        response = redirect(url_for("login"))
        response.delete_cookie(COOKIE_NAME)
        return response

    @app.get("/portal")
    @login_required("user")
    def portal() -> str:
        user = repository.get_user(int(g.current_user["id"]))
        assert user is not None
        remaining = max(0, int(user["quota_bytes"]) - int(user["used_bytes"]))
        return render_template(
            "portal.html",
            user=user,
            remaining=remaining,
            quota_requests=repository.list_quota_requests(int(user["id"])),
        )

    @app.post("/portal/quota")
    @login_required("user")
    def purchase_quota() -> Response:
        try:
            mebibytes = int(request.form.get("mebibytes", "0"))
        except ValueError:
            abort(400, "invalid quota amount")
        if mebibytes not in {50, 100, 500, 1024}:
            abort(400, "unsupported quota package")
        user_id = int(g.current_user["id"])
        repository.purchase_quota(user_id, mebibytes * 1024 * 1024)
        vpn_server.accounting.refresh(user_id)
        flash(f"{mebibytes} MiB was approved and added to your account.", "success")
        return redirect(url_for("portal"))

    @app.get("/admin")
    @login_required("admin")
    def admin() -> str:
        return render_template(
            "admin.html",
            users=repository.list_users(),
            active_clients=[item.status() for item in vpn_server.manager.snapshot()],
            sessions=repository.list_vpn_sessions(),
            traffic=repository.list_traffic(),
            rules=repository.list_firewall_rules(),
            firewall_log=repository.list_firewall_log(),
        )

    @app.get("/api/admin/live")
    @login_required("admin")
    def admin_live() -> Response:
        return jsonify(
            {
                "connected_clients": vpn_server.manager.count(),
                "clients": [item.status() for item in vpn_server.manager.snapshot()],
            }
        )

    @app.post("/admin/users")
    @login_required("admin")
    def create_user() -> Response:
        try:
            repository.create_user(
                request.form.get("username", ""),
                request.form.get("password", ""),
                quota_bytes=int(request.form.get("quota_mib", "100")) * 1024 * 1024,
                upload_rate_bps=int(request.form.get("upload_kib", "0")) * 1024,
                download_rate_bps=int(request.form.get("download_kib", "0")) * 1024,
            )
            flash("User created.", "success")
        except Exception as exc:
            flash(f"Could not create user: {exc}", "error")
        return redirect(url_for("admin"))

    @app.post("/admin/users/<int:user_id>/status")
    @login_required("admin")
    def user_status(user_id: int) -> Response:
        status = request.form.get("status", "")
        if status not in {"active", "blocked"}:
            abort(400, "invalid status")
        repository.set_user_status(user_id, status)
        if status == "blocked":
            vpn_server.manager.kick_user(user_id, "admin_ban")
        flash(f"User status changed to {status}.", "success")
        return redirect(url_for("admin"))

    @app.post("/admin/users/<int:user_id>/limits")
    @login_required("admin")
    def user_limits(user_id: int) -> Response:
        try:
            quota = int(request.form.get("quota_mib", "0")) * 1024 * 1024
            upload = int(request.form.get("upload_kib", "0")) * 1024
            download = int(request.form.get("download_kib", "0")) * 1024
            repository.update_user_limits(
                user_id,
                quota_bytes=quota,
                upload_rate_bps=upload,
                download_rate_bps=download,
            )
            vpn_server.accounting.refresh(user_id)
            for connection in vpn_server.manager.get_by_user(user_id):
                connection.upload_limiter = TokenBucket(upload)
                connection.download_limiter = TokenBucket(download)
            flash("Quota and rate limits updated.", "success")
        except (ValueError, KeyError) as exc:
            flash(f"Invalid limits: {exc}", "error")
        return redirect(url_for("admin"))

    @app.post("/admin/kick/<client_id>")
    @login_required("admin")
    def kick(client_id: str) -> Response:
        if vpn_server.manager.kick_client(client_id, "admin_kick"):
            flash(f"Client {client_id} disconnected.", "success")
        else:
            flash("Client is no longer connected.", "error")
        return redirect(url_for("admin"))

    @app.post("/admin/firewall")
    @login_required("admin")
    def add_firewall_rule() -> Response:
        user_value = request.form.get("user_id", "global")
        destination_ip = request.form.get("destination_ip", "").strip() or None
        domain = request.form.get("domain", "").strip().lower() or None
        port_value = request.form.get("destination_port", "").strip()
        protocol = request.form.get("protocol", "").upper() or None
        try:
            user_id = None if user_value == "global" else int(user_value)
            destination_port = int(port_value) if port_value else None
            if destination_ip:
                destination_ip = str(ipaddress.ip_network(destination_ip, strict=False))
            if destination_port is not None and not 0 <= destination_port <= 65535:
                raise ValueError("port must be between 0 and 65535")
            if protocol not in {None, "TCP", "UDP", "ICMP"}:
                raise ValueError("invalid protocol")
            repository.add_firewall_rule(
                user_id=user_id,
                destination_ip=destination_ip,
                destination_port=destination_port,
                protocol=protocol,
                domain=domain,
                action=request.form.get("action", "block"),
                priority=int(request.form.get("priority", "100")),
            )
            vpn_server.firewall.refresh()
            flash("Firewall rule added and activated.", "success")
        except (ValueError, KeyError) as exc:
            flash(f"Invalid firewall rule: {exc}", "error")
        return redirect(url_for("admin"))

    @app.post("/admin/firewall/<int:rule_id>/delete")
    @login_required("admin")
    def delete_firewall_rule(rule_id: int) -> Response:
        repository.delete_firewall_rule(rule_id)
        vpn_server.firewall.refresh()
        flash("Firewall rule deleted.", "success")
        return redirect(url_for("admin"))

    return app
