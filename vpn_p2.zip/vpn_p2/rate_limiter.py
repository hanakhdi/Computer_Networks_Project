from __future__ import annotations

import threading
import time
from collections.abc import Callable


class TokenBucket:
    """Thread-safe byte token bucket. A rate of zero means unlimited."""

    def __init__(
        self,
        rate_bps: int,
        *,
        burst_seconds: float = 1.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if rate_bps < 0 or burst_seconds <= 0:
            raise ValueError("rate must be non-negative and burst must be positive")
        self.rate = float(rate_bps)
        self.capacity = max(self.rate * burst_seconds, 1.0)
        self.tokens = self.capacity
        self.clock = clock
        self.updated_at = clock()
        self._lock = threading.Lock()

    @property
    def unlimited(self) -> bool:
        return self.rate == 0

    def delay_for(self, amount: int) -> float:
        if amount < 0:
            raise ValueError("amount cannot be negative")
        if self.unlimited or amount == 0:
            return 0.0
        with self._lock:
            now = self.clock()
            elapsed = max(0.0, now - self.updated_at)
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            self.updated_at = now
            if self.tokens >= amount:
                self.tokens -= amount
                return 0.0
            missing = amount - self.tokens
            self.tokens = 0.0
            return missing / self.rate

    def wait(self, amount: int, stop_event: threading.Event) -> bool:
        remaining = self.delay_for(amount)
        while remaining > 0:
            started = time.monotonic()
            if stop_event.wait(min(remaining, 0.25)):
                return False
            remaining -= time.monotonic() - started
        return not stop_event.is_set()
