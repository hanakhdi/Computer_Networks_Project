#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname -- "$0")"

exec sudo --preserve-env=VPN_PSK,VPN_WEB_SECRET,VPN_ADMIN_USERNAME,VPN_ADMIN_PASSWORD,VPN_DEMO_USERNAME,VPN_DEMO_PASSWORD python3 server.py \
  --bind 0.0.0.0 \
  --port 9000 \
  --status-port 9200 \
  --psk "${VPN_PSK:-classroom-secret}" \
  --database "${VPN_DATABASE:-data/vpn.db}" \
  --web-bind 0.0.0.0 \
  --web-port "${VPN_WEB_PORT:-8080}" \
  --tun-name tun0 \
  --show-mappings
