from __future__ import annotations

import argparse
import getpass
import json
import os
import queue
import select
import signal
import socket
import struct
import sys
import threading
import time

from common import (
    DEFAULT_LB_PORT,
    DEFAULT_PORT,
    DEFAULT_PSK,
    DEFAULT_TUN_MTU,
    HEARTBEAT_INTERVAL,
    HEARTBEAT_TIMEOUT,
    CaesarChannel,
    AuthenticationError,
    Message,
    MessageType,
    Reassembler,
    RouteManager,
    TunDevice,
    client_channel_handshake,
    configure_tun,
    create_tun,
    make_messages,
    parse_ipv4,
    recv_exact,
    recv_frame,
    recv_line,
    send_frame,
)


def negotiate_socks5(client_sock: socket.socket) -> tuple[str, int]:
    """Perform a no-auth SOCKS5 CONNECT handshake and return its target."""
    version, method_count = recv_exact(client_sock, 2)
    if version != 5:
        raise ValueError("only SOCKS5 is supported")
    methods = recv_exact(client_sock, method_count)
    if 0 not in methods:
        client_sock.sendall(b"\x05\xff")
        raise ValueError("SOCKS client did not offer no-authentication mode")
    client_sock.sendall(b"\x05\x00")

    version, command, reserved, address_type = recv_exact(client_sock, 4)
    if version != 5 or reserved != 0:
        raise ValueError("malformed SOCKS5 request")
    if command != 1:
        send_socks5_reply(client_sock, 7)
        raise ValueError("only SOCKS5 CONNECT is supported")

    if address_type == 1:
        host = socket.inet_ntop(socket.AF_INET, recv_exact(client_sock, 4))
    elif address_type == 3:
        name_length = recv_exact(client_sock, 1)[0]
        if name_length == 0:
            raise ValueError("empty SOCKS5 domain name")
        host = recv_exact(client_sock, name_length).decode("idna")
    elif address_type == 4:
        host = socket.inet_ntop(socket.AF_INET6, recv_exact(client_sock, 16))
    else:
        send_socks5_reply(client_sock, 8)
        raise ValueError("unsupported SOCKS5 address type")

    (port,) = struct.unpack("!H", recv_exact(client_sock, 2))
    if port == 0:
        raise ValueError("SOCKS5 destination port cannot be zero")
    return host, port


def send_socks5_reply(client_sock: socket.socket, reply: int) -> None:
    client_sock.sendall(b"\x05" + bytes([reply]) + b"\x00\x01\x00\x00\x00\x00\x00\x00")


class VPNClient:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.stop_event = threading.Event()
        self.sock: socket.socket | None = None
        self.channel: CaesarChannel | None = None
        self.tun: TunDevice | None = None
        self.route_manager: RouteManager | None = None
        self.proxy_listener: socket.socket | None = None
        self.virtual_ip: str | None = None
        self.send_lock = threading.Lock()
        self.reassembler = Reassembler()
        self.last_peer_alive = time.monotonic()
        self._threads: list[threading.Thread] = []
        self._cleanup_lock = threading.Lock()
        self._cleaned = False
        self._proxy_lock = threading.Lock()
        self._proxy_next_stream = 1
        self._proxy_streams: dict[
            int, queue.Queue[tuple[MessageType, bytes]]
        ] = {}
        self._proxy_clients: dict[int, socket.socket] = {}

    def resolve_server(self) -> tuple[str, int]:
        if not self.args.load_balancer:
            return self.args.server_ip, self.args.port

        print(
            f"[CLIENT] asking load balancer "
            f"{self.args.load_balancer}:{self.args.lb_port}"
        )
        request = json.dumps(
            {"client_id": self.args.client_id}, separators=(",", ":")
        ).encode("utf-8")
        with socket.create_connection(
            (self.args.load_balancer, self.args.lb_port), timeout=5.0
        ) as lb_sock:
            lb_sock.sendall(request + b"\n")
            response = recv_line(lb_sock)
        data = json.loads(response.decode("utf-8"))
        if not data.get("ok"):
            raise RuntimeError(
                f"load balancer rejected request: {data.get('error')}"
            )
        return str(data["server_ip"]), int(data["server_port"])

    def send_message(
        self,
        msg_type: MessageType,
        payload: bytes = b"",
        session_id: int = 0,
    ) -> None:
        if self.sock is None or self.channel is None:
            raise ConnectionError("VPN channel is not established")
        with self.send_lock:
            for message in make_messages(msg_type, payload, session_id):
                send_frame(
                    self.sock, self.channel.encrypt(message.encode())
                )

    def _start_thread(self, target: object, name: str) -> None:
        thread = threading.Thread(target=target, name=name, daemon=True)
        thread.start()
        self._threads.append(thread)

    def run(self) -> None:
        server_host, server_port = self.resolve_server()
        server_ip = socket.gethostbyname(server_host)
        print(f"[CLIENT] connecting to {server_ip}:{server_port}")
        try:
            self.sock = socket.create_connection(
                (server_ip, server_port), timeout=10.0
            )
            self.channel = client_channel_handshake(
                self.sock, self.args.client_id, self.args.psk
            )
            username = self.args.username or input("VPN username: ").strip()
            password = self.args.password or getpass.getpass("VPN password: ")
            self.send_message(
                MessageType.AUTH_REQUEST,
                json.dumps(
                    {
                        "username": username,
                        "password": password,
                        "mode": "proxy" if self.args.proxy_mode else "tun",
                    },
                    separators=(",", ":"),
                ).encode("utf-8"),
            )
            response = self._receive_auth_response()
            if not response.get("ok"):
                raise AuthenticationError(
                    str(response.get("error") or "user authentication failed")
                )
            self.virtual_ip = str(response["virtual_ip"])
            self.sock.settimeout(None)
            print(
                f"[CLIENT] authenticated as {username}; assigned {self.virtual_ip}"
            )

            if self.args.proxy_mode:
                self._start_proxy_listener()
                self._start_thread(self.server_to_client, "server-to-proxy")
                self._start_thread(self.heartbeat_loop, "heartbeats")
                self._start_thread(self.proxy_accept_loop, "socks5-listener")
                while not self.stop_event.wait(0.5):
                    pass
                return

            self.tun = create_tun(self.args.tun_name)
            configure_tun(
                self.tun.name,
                f"{self.virtual_ip}/24",
                self.args.mtu,
            )
            self.route_manager = RouteManager(self.tun.name)

            if self.args.full_tunnel:
                self.route_manager.enable_full_tunnel(server_ip)
                print(
                    "[CLIENT] full tunnel enabled with two /1 routes; "
                    "the VPN server keeps a physical /32 route"
                )
            else:
                for network in self.args.route:
                    self.route_manager.add_tunnel_route(network)
                    print(f"[CLIENT] tunnel route added: {network}")

            self._start_thread(self.tun_to_server, "tun-to-server")
            self._start_thread(self.server_to_client, "server-to-tun")
            self._start_thread(self.heartbeat_loop, "heartbeats")

            while not self.stop_event.wait(0.5):
                pass
        finally:
            self.cleanup()

    def _receive_auth_response(self) -> dict[str, object]:
        assert self.sock is not None
        assert self.channel is not None
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            encrypted = recv_frame(self.sock)
            message = Message.decode(self.channel.decrypt(encrypted))
            reassembled = self.reassembler.add(message)
            if reassembled is None:
                continue
            msg_type, _session_id, payload = reassembled
            if msg_type != MessageType.AUTH_RESPONSE:
                raise AuthenticationError("server sent data before authentication")
            try:
                result = json.loads(payload.decode("utf-8"))
            except (UnicodeError, json.JSONDecodeError) as exc:
                raise AuthenticationError("malformed authentication response") from exc
            if not isinstance(result, dict):
                raise AuthenticationError("malformed authentication response")
            return result
        raise AuthenticationError("user authentication timed out")

    def tun_to_server(self) -> None:
        assert self.tun is not None
        while not self.stop_event.is_set():
            try:
                readable, _, _ = select.select(
                    [self.tun.fd], [], [], 1.0
                )
                if not readable:
                    continue
                packet = os.read(self.tun.fd, 65535)
            except (OSError, ValueError):
                break
            try:
                flow = parse_ipv4(packet)
                self.send_message(
                    MessageType.DATA, packet, flow.session_id
                )
            except ValueError as exc:
                print(f"[CLIENT] ignored malformed TUN packet: {exc}")
            except (ConnectionError, OSError) as exc:
                if not self.stop_event.is_set():
                    print(f"[CLIENT] send path stopped: {exc}")
                self.request_stop()
                break

    def server_to_client(self) -> None:
        assert self.sock is not None
        assert self.channel is not None
        while not self.stop_event.is_set():
            try:
                encrypted = recv_frame(self.sock)
                message = Message.decode(self.channel.decrypt(encrypted))
                reassembled = self.reassembler.add(message)
                if reassembled is None:
                    continue
                msg_type, _session_id, payload = reassembled
                self.last_peer_alive = time.monotonic()

                if msg_type == MessageType.DATA:
                    if self.tun is None:
                        raise ValueError("server sent TUN data in proxy mode")
                    flow = parse_ipv4(payload)
                    if (
                        self.virtual_ip is not None
                        and flow.destination_ip != self.virtual_ip
                    ):
                        print(
                            f"[CLIENT] dropped packet for unexpected "
                            f"destination {flow.destination_ip}"
                        )
                        continue
                    os.write(self.tun.fd, payload)
                elif msg_type in {
                    MessageType.PROXY_CONNECTED,
                    MessageType.PROXY_DATA,
                    MessageType.PROXY_CLOSE,
                }:
                    if not self.args.proxy_mode:
                        raise ValueError("server sent proxy data in TUN mode")
                    self._dispatch_proxy_message(msg_type, _session_id, payload)
                elif msg_type == MessageType.HEARTBEAT:
                    self.send_message(MessageType.HEARTBEAT_ACK)
                elif msg_type == MessageType.CLOSE:
                    print("[CLIENT] server requested connection close")
                    self.request_stop()
                    break
                elif msg_type == MessageType.QUOTA_EXHAUSTED:
                    print("[CLIENT] traffic quota exhausted; use the web portal to add quota")
                    self.request_stop()
                    break
            except Exception as exc:
                if not self.stop_event.is_set():
                    print(f"[CLIENT] receive path stopped: {exc}")
                self.request_stop()
                break

    def _start_proxy_listener(self) -> None:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((self.args.proxy_bind, self.args.proxy_port))
        listener.listen(64)
        listener.settimeout(1.0)
        self.proxy_listener = listener
        print(
            f"[CLIENT] SOCKS5 proxy listening on "
            f"{self.args.proxy_bind}:{self.args.proxy_port}"
        )

    def _allocate_proxy_stream(
        self, client_sock: socket.socket
    ) -> tuple[int, queue.Queue[tuple[MessageType, bytes]]]:
        with self._proxy_lock:
            for _ in range(0xFFFFFFFF):
                stream_id = self._proxy_next_stream
                self._proxy_next_stream = 1 if stream_id == 0xFFFFFFFF else stream_id + 1
                if stream_id not in self._proxy_streams:
                    events: queue.Queue[tuple[MessageType, bytes]] = queue.Queue()
                    self._proxy_streams[stream_id] = events
                    self._proxy_clients[stream_id] = client_sock
                    return stream_id, events
        raise RuntimeError("no SOCKS5 stream IDs are available")

    def _remove_proxy_stream(self, stream_id: int) -> None:
        with self._proxy_lock:
            self._proxy_streams.pop(stream_id, None)
            self._proxy_clients.pop(stream_id, None)

    def _dispatch_proxy_message(
        self, msg_type: MessageType, stream_id: int, payload: bytes
    ) -> None:
        with self._proxy_lock:
            events = self._proxy_streams.get(stream_id)
        if events is not None:
            events.put((msg_type, payload))

    def proxy_accept_loop(self) -> None:
        assert self.proxy_listener is not None
        while not self.stop_event.is_set():
            try:
                client_sock, address = self.proxy_listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            thread = threading.Thread(
                target=self.handle_socks_client,
                args=(client_sock, address),
                name=f"socks-{address[0]}:{address[1]}",
                daemon=True,
            )
            thread.start()
            self._threads.append(thread)

    def handle_socks_client(
        self, client_sock: socket.socket, address: tuple[str, int]
    ) -> None:
        stream_id: int | None = None
        events: queue.Queue[tuple[MessageType, bytes]] | None = None
        try:
            client_sock.settimeout(10.0)
            host, port = negotiate_socks5(client_sock)
            stream_id, events = self._allocate_proxy_stream(client_sock)
            request = json.dumps(
                {"host": host, "port": port}, separators=(",", ":")
            ).encode("utf-8")
            self.send_message(MessageType.PROXY_CONNECT, request, stream_id)

            msg_type, payload = events.get(timeout=12.0)
            if msg_type != MessageType.PROXY_CONNECTED:
                raise ConnectionError("proxy stream closed before CONNECT completed")
            result = json.loads(payload.decode("utf-8"))
            if not isinstance(result, dict) or not result.get("ok"):
                send_socks5_reply(client_sock, 5)
                error = result.get("error", "connection failed") if isinstance(result, dict) else "connection failed"
                print(f"[PROXY] {host}:{port} rejected: {error}")
                return

            send_socks5_reply(client_sock, 0)
            client_sock.settimeout(0.2)
            print(
                f"[PROXY] stream={stream_id} local={address[0]}:{address[1]} "
                f"target={host}:{port}"
            )
            while not self.stop_event.is_set():
                while True:
                    try:
                        incoming_type, incoming = events.get_nowait()
                    except queue.Empty:
                        break
                    if incoming_type == MessageType.PROXY_DATA:
                        client_sock.sendall(incoming)
                    elif incoming_type == MessageType.PROXY_CLOSE:
                        return

                try:
                    outgoing = client_sock.recv(65535)
                except socket.timeout:
                    continue
                if not outgoing:
                    return
                self.send_message(MessageType.PROXY_DATA, outgoing, stream_id)
        except (ConnectionError, OSError, ValueError, json.JSONDecodeError, queue.Empty) as exc:
            if not self.stop_event.is_set():
                print(f"[PROXY] client {address[0]}:{address[1]} ended: {exc}")
        finally:
            if stream_id is not None:
                try:
                    self.send_message(MessageType.PROXY_CLOSE, b"", stream_id)
                except (ConnectionError, OSError):
                    pass
                self._remove_proxy_stream(stream_id)
            try:
                client_sock.close()
            except OSError:
                pass

    def heartbeat_loop(self) -> None:
        while not self.stop_event.wait(HEARTBEAT_INTERVAL):
            if (
                time.monotonic() - self.last_peer_alive
                > HEARTBEAT_TIMEOUT
            ):
                print("[CLIENT] server heartbeat timeout")
                self.request_stop()
                return
            try:
                self.send_message(MessageType.HEARTBEAT)
            except (ConnectionError, OSError):
                self.request_stop()
                return

    def request_stop(self) -> None:
        if self.stop_event.is_set():
            return
        self.stop_event.set()
        if self.sock is not None:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
        if self.tun is not None:
            self.tun.close()
        if self.proxy_listener is not None:
            try:
                self.proxy_listener.close()
            except OSError:
                pass
        with self._proxy_lock:
            proxy_clients = list(self._proxy_clients.values())
        for client_sock in proxy_clients:
            try:
                client_sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                client_sock.close()
            except OSError:
                pass

    def cleanup(self) -> None:
        with self._cleanup_lock:
            if self._cleaned:
                return
            self._cleaned = True
        self.request_stop()
        current = threading.current_thread()
        for thread in self._threads:
            if thread is not current:
                thread.join(timeout=1.0)
        if self.route_manager is not None:
            self.route_manager.cleanup()
        print("[CLIENT] VPN resources and socket cleaned up")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Layer-3 TUN VPN client")
    parser.add_argument("--server-ip", default="10.10.10.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--client-id", default=socket.gethostname())
    parser.add_argument("--psk", default=DEFAULT_PSK)
    parser.add_argument("--username", default=os.environ.get("VPN_USERNAME"))
    parser.add_argument(
        "--password",
        default=os.environ.get("VPN_PASSWORD"),
        help="VPN password; prefer VPN_PASSWORD or the interactive prompt",
    )
    parser.add_argument("--tun-name", default="tun0")
    parser.add_argument("--mtu", type=int, default=DEFAULT_TUN_MTU)
    parser.add_argument(
        "--route",
        action="append",
        default=[],
        help="IPv4 network routed through TUN; may be repeated",
    )
    parser.add_argument("--full-tunnel", action="store_true")
    parser.add_argument(
        "--proxy-mode",
        action="store_true",
        help="run a local SOCKS5 proxy instead of creating a TUN interface",
    )
    parser.add_argument("--proxy-bind", default="127.0.0.1")
    parser.add_argument("--proxy-port", type=int, default=1080)
    parser.add_argument("--load-balancer", help="load balancer IP or hostname")
    parser.add_argument("--lb-port", type=int, default=DEFAULT_LB_PORT)
    args = parser.parse_args()
    if args.proxy_mode and (args.full_tunnel or args.route):
        parser.error("--proxy-mode cannot be combined with --full-tunnel or --route")
    if not 1 <= args.proxy_port <= 65535:
        parser.error("proxy port must be between 1 and 65535")
    return args


def main() -> None:
    args = parse_args()
    client = VPNClient(args)
    signal.signal(signal.SIGINT, lambda _signum, _frame: client.request_stop())
    signal.signal(signal.SIGTERM, lambda _signum, _frame: client.request_stop())
    try:
        client.run()
    except Exception as exc:
        print(f"[CLIENT] fatal error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
