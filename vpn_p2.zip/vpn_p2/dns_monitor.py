from __future__ import annotations

import ipaddress
import struct
import threading
import time

from common import parse_ipv4


def _udp_payload(packet: bytes) -> tuple[int, int, bytes] | None:
    flow = parse_ipv4(packet)
    if flow.protocol != 17:
        return None
    ihl = (packet[0] & 0x0F) * 4
    if len(packet) < ihl + 8:
        return None
    source_port, destination_port, length = struct.unpack(
        "!HHH", packet[ihl : ihl + 6]
    )
    if length < 8 or len(packet) < ihl + length:
        return None
    return source_port, destination_port, packet[ihl + 8 : ihl + length]


def _read_name(data: bytes, offset: int, depth: int = 0) -> tuple[str, int]:
    if depth > 12:
        raise ValueError("DNS compression loop")
    labels: list[str] = []
    original_next: int | None = None
    while True:
        if offset >= len(data):
            raise ValueError("truncated DNS name")
        length = data[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0 == 0xC0:
            if offset + 1 >= len(data):
                raise ValueError("truncated DNS pointer")
            pointer = ((length & 0x3F) << 8) | data[offset + 1]
            if original_next is None:
                original_next = offset + 2
            pointed, _ = _read_name(data, pointer, depth + 1)
            labels.append(pointed)
            offset += 2
            break
        if length > 63 or offset + 1 + length > len(data):
            raise ValueError("invalid DNS label")
        labels.append(data[offset + 1 : offset + 1 + length].decode("idna"))
        offset += 1 + length
    return ".".join(part for part in labels if part), original_next or offset


class DNSMonitor:
    def __init__(self, ttl: float = 300.0) -> None:
        self.ttl = ttl
        self._queries: dict[tuple[int, int], tuple[str, float]] = {}
        self._answers: dict[tuple[int, str], tuple[str, float]] = {}
        self._lock = threading.Lock()

    def observe_outgoing(self, user_id: int, packet: bytes) -> str | None:
        try:
            udp = _udp_payload(packet)
            if udp is None or udp[1] != 53 or len(udp[2]) < 12:
                return None
            data = udp[2]
            transaction_id, flags, questions = struct.unpack("!HHH", data[:6])
            if flags & 0x8000 or questions < 1:
                return None
            domain, _ = _read_name(data, 12)
        except (UnicodeError, ValueError, struct.error):
            return None
        with self._lock:
            self._expire_locked(time.time())
            self._queries[(user_id, transaction_id)] = (domain, time.time())
        return domain

    def observe_incoming(self, user_id: int, packet: bytes) -> None:
        try:
            udp = _udp_payload(packet)
            if udp is None or udp[0] != 53 or len(udp[2]) < 12:
                return
            data = udp[2]
            transaction_id, flags, questions, answers = struct.unpack(
                "!HHHH", data[:8]
            )
            if not flags & 0x8000:
                return
            with self._lock:
                query = self._queries.get((user_id, transaction_id))
            if query is None:
                return
            domain = query[0]
            offset = 12
            for _ in range(questions):
                _, offset = _read_name(data, offset)
                offset += 4
            found: list[str] = []
            for _ in range(answers):
                _, offset = _read_name(data, offset)
                if offset + 10 > len(data):
                    break
                record_type, _record_class, _ttl, length = struct.unpack(
                    "!HHIH", data[offset : offset + 10]
                )
                offset += 10
                if offset + length > len(data):
                    break
                if record_type == 1 and length == 4:
                    found.append(str(ipaddress.IPv4Address(data[offset : offset + 4])))
                offset += length
        except (UnicodeError, ValueError, struct.error):
            return
        now = time.time()
        with self._lock:
            self._expire_locked(now)
            for address in found:
                self._answers[(user_id, address)] = (domain, now)

    def lookup(self, user_id: int, destination_ip: str) -> str | None:
        now = time.time()
        with self._lock:
            self._expire_locked(now)
            answer = self._answers.get((user_id, destination_ip))
            return None if answer is None else answer[0]

    def _expire_locked(self, now: float) -> None:
        self._queries = {
            key: value for key, value in self._queries.items() if now - value[1] <= self.ttl
        }
        self._answers = {
            key: value for key, value in self._answers.items() if now - value[1] <= self.ttl
        }
