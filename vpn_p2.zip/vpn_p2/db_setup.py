from __future__ import annotations

import argparse
import getpass

from database import Repository


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Initialize and manage the VPN database")
    parser.add_argument("--database", default="data/vpn.db")
    subcommands = parser.add_subparsers(dest="command", required=True)
    subcommands.add_parser("init", help="create or migrate the schema")
    subcommands.add_parser("list-users", help="show configured accounts")
    create = subcommands.add_parser("create-user", help="create a VPN or admin user")
    create.add_argument("username")
    create.add_argument("--role", choices=("user", "admin"), default="user")
    create.add_argument("--quota-mib", type=int, default=100)
    create.add_argument("--upload-kib", type=int, default=512)
    create.add_argument("--download-kib", type=int, default=1024)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repository = Repository(args.database)
    repository.initialize()
    if args.command == "init":
        print(f"Database initialized: {repository.path}")
    elif args.command == "list-users":
        for user in repository.list_users():
            print(
                f"{user['id']:>3}  {user['username']:<20} "
                f"role={user['role']:<5} status={user['status']}"
            )
    elif args.command == "create-user":
        password = getpass.getpass("Password: ")
        confirmation = getpass.getpass("Confirm password: ")
        if password != confirmation:
            raise SystemExit("Passwords do not match")
        user_id = repository.create_user(
            args.username,
            password,
            role=args.role,
            quota_bytes=args.quota_mib * 1024 * 1024,
            upload_rate_bps=args.upload_kib * 1024,
            download_rate_bps=args.download_kib * 1024,
        )
        print(f"Created {args.role} user {args.username!r} with id {user_id}")


if __name__ == "__main__":
    main()
