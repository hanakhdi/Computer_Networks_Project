from __future__ import annotations

import argparse
import ipaddress
import json
import os
import queue
import re
import select
import signal
import socket
import sys
import threading
import time
from dataclasses import dataclass, field

from accounting import AccountingService
from auth_service import AuthService, AuthenticatedUser
from database import Repository
from dns_monitor import DNSMonitor
from firewall import FirewallEngine
from rate_limiter import TokenBucket

from common import (
    DEFAULT_PORT,
    DEFAULT_PSK,
    DEFAULT_STATUS_PORT,
    DEFAULT_TUN_MTU,
    HEARTBEAT_INTERVAL,
    HEARTBEAT_TIMEOUT,
    SERVER_TUN_IP_CIDR,
    VPN_SUBNET,
    CaesarChannel,
    Flow,
    Message,
    MessageType,
    Reassembler,
    TunDevice,
    configure_tun,
    create_tun,
    make_messages,
    parse_ipv4,
    recv_frame,
    run_network_command,
    send_frame,
    server_channel_handshake,
)


class ClientManager:
    def __init__(self, subnet: str = VPN_SUBNET) -> None:
        network = ipaddress.IPv4Network(subnet)
        self._pool = [str(address) for address in list(network.hosts())[1:]]
        self._by_ip: dict[str, ClientConnection] = {}
        self._by_id: dict[str, ClientConnection] = {}
        self._reserved_ips: set[str] = set()
        self._claimed_ids: set[str] = set()
        self._lock = threading.RLock()

    def reserve_ip(self) -> str:
        with self._lock:
            for candidate in self._pool:
                if candidate not in self._by_ip and candidate not in self._reserved_ips:
                    self._reserved_ips.add(candidate)
                    return candidate
        raise RuntimeError("virtual IP pool is exhausted")

    def claim_client_id(self, client_id: str) -> bool:
        with self._lock:
            existing = self._by_id.get(client_id)
            if existing is not None and not existing.closed.is_set():
                return False
            if client_id in self._claimed_ids:
                return False
            if existing is not None:
                self._by_id.pop(client_id, None)
                self._by_ip.pop(existing.virtual_ip, None)
            self._claimed_ids.add(client_id)
            return True

    def register(self, connection: ClientConnection) -> None:
        with self._lock:
            if connection.virtual_ip not in self._reserved_ips:
                raise RuntimeError("virtual IP was not reserved")
            if connection.client_id not in self._claimed_ids:
                raise RuntimeError("client ID was not claimed")
            if connection.virtual_ip in self._by_ip:
                raise RuntimeError("virtual IP is already active")
            if connection.client_id in self._by_id:
                raise RuntimeError("client ID is already active")
            self._reserved_ips.remove(connection.virtual_ip)
            self._claimed_ids.remove(connection.client_id)
            self._by_ip[connection.virtual_ip] = connection
            self._by_id[connection.client_id] = connection

    def release_pending(
        self, virtual_ip: str | None, client_id: str | None
    ) -> None:
        with self._lock:
            if virtual_ip is not None:
                self._reserved_ips.discard(virtual_ip)
            if client_id is not None:
                self._claimed_ids.discard(client_id)

    def unregister(self, connection: ClientConnection) -> None:
        with self._lock:
            if self._by_id.get(connection.client_id) is connection:
                self._by_id.pop(connection.client_id, None)
            if self._by_ip.get(connection.virtual_ip) is connection:
                self._by_ip.pop(connection.virtual_ip, None)
            self._reserved_ips.discard(connection.virtual_ip)
            self._claimed_ids.discard(connection.client_id)

    def get_by_ip(self, virtual_ip: str) -> ClientConnection | None:
        with self._lock:
            return self._by_ip.get(virtual_ip)

    def get_by_id(self, client_id: str) -> ClientConnection | None:
        with self._lock:
            return self._by_id.get(client_id)

    def get_by_user(self, user_id: int) -> list[ClientConnection]:
        with self._lock:
            return [
                connection
                for connection in self._by_id.values()
                if connection.user_id == user_id
            ]

    def kick_client(self, client_id: str, reason: str = "admin_kick") -> bool:
        connection = self.get_by_id(client_id)
        if connection is None:
            return False
        connection.close(reason)
        return True

    def kick_user(self, user_id: int, reason: str = "admin_kick") -> int:
        connections = self.get_by_user(user_id)
        for connection in connections:
            connection.close(reason)
        return len(connections)

    def snapshot(self) -> list[ClientConnection]:
        with self._lock:
            return list(self._by_id.values())

    def count(self) -> int:
        with self._lock:
            return len(self._by_id)


@dataclass
class ClientConnection:
    sock: socket.socket
    address: tuple[str, int]
    channel: CaesarChannel
    client_id: str
    virtual_ip: str
    user_id: int
    username: str
    db_session_id: int
    upload_limiter: TokenBucket
    download_limiter: TokenBucket
    mode: str = "tun"
    connected_at: float = field(default_factory=time.time)
    bytes_received: int = 0
    bytes_sent: int = 0
    last_heartbeat_time: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        self.send_lock = threading.Lock()
        self.reassembler = Reassembler()
        self.closed = threading.Event()
        self.last_peer_alive = time.monotonic()
        self.disconnect_reason = "connection_closed"
        self.download_queue: queue.Queue[tuple[bytes, int]] = queue.Queue(maxsize=256)
        self.proxy_lock = threading.Lock()
        self.proxy_sockets: dict[int, socket.socket] = {}

    def mark_peer_alive(self) -> None:
        self.last_peer_alive = time.monotonic()
        self.last_heartbeat_time = time.time()

    def send_message(
        self,
        msg_type: MessageType,
        payload: bytes = b"",
        session_id: int = 0,
    ) -> None:
        with self.send_lock:
            if self.closed.is_set():
                raise ConnectionError("client connection is closed")
            for message in make_messages(msg_type, payload, session_id):
                send_frame(self.sock, self.channel.encrypt(message.encode()))

    def close(self, reason: str = "connection_closed") -> None:
        if self.closed.is_set():
            return
        self.disconnect_reason = reason
        self.closed.set()
        with self.proxy_lock:
            proxy_sockets = list(self.proxy_sockets.values())
            self.proxy_sockets.clear()
        for proxy_sock in proxy_sockets:
            try:
                proxy_sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                proxy_sock.close()
            except OSError:
                pass
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass

    def status(self) -> dict[str, object]:
        return {
            "client_id": self.client_id,
            "user_id": self.user_id,
            "username": self.username,
            "session_id": self.db_session_id,
            "real_ip": self.address[0],
            "real_port": self.address[1],
            "virtual_ip": self.virtual_ip,
            "mode": self.mode,
            "connected_at": self.connected_at,
            "connected_seconds": round(time.time() - self.connected_at, 1),
            "bytes_received": self.bytes_received,
            "bytes_sent": self.bytes_sent,
            "last_heartbeat_time": self.last_heartbeat_time,
            "disconnect_reason": self.disconnect_reason,
        }


@dataclass
class PortMappingEntry:
    client_id: str
    client_virtual_ip: str
    protocol: str
    source_ip: str
    source_port: int
    destination_ip: str
    destination_port: int
    session_id: int
    first_seen: float
    last_seen: float
    packet_count: int = 1


class PortMappingTable:
    def __init__(self) -> None:
        self._entries: dict[tuple[object, ...], PortMappingEntry] = {}
        self._lock = threading.Lock()

    def update(
        self, client_id: str, client_virtual_ip: str, flow: Flow, session_id: int
    ) -> bool:
        key = (
            client_id,
            flow.protocol,
            flow.source_ip,
            flow.source_port,
            flow.destination_ip,
            flow.destination_port,
        )
        now = time.time()
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                self._entries[key] = PortMappingEntry(
                    client_id=client_id,
                    client_virtual_ip=client_virtual_ip,
                    protocol=flow.protocol_name,
                    source_ip=flow.source_ip,
                    source_port=flow.source_port,
                    destination_ip=flow.destination_ip,
                    destination_port=flow.destination_port,
                    session_id=session_id,
                    first_seen=now,
                    last_seen=now,
                )
                return True
            else:
                entry.last_seen = now
                entry.packet_count += 1
                entry.session_id = session_id
                return False

    def remove_client(self, client_id: str) -> int:
        with self._lock:
            keys = [
                key
                for key, entry in self._entries.items()
                if entry.client_id == client_id
            ]
            for key in keys:
                del self._entries[key]
            return len(keys)

    def expire_stale(self, max_age: float) -> int:
        cutoff = time.time() - max_age
        with self._lock:
            keys = [
                key
                for key, entry in self._entries.items()
                if entry.last_seen < cutoff
            ]
            for key in keys:
                del self._entries[key]
            return len(keys)

    def snapshot(self) -> list[PortMappingEntry]:
        with self._lock:
            return list(self._entries.values())

    def print_compact(self) -> None:
        entries = sorted(
            self.snapshot(),
            key=lambda entry: (entry.client_id, entry.first_seen),
        )
        now = time.time()
        print(f"[MAPPINGS] active flows: {len(entries)}")
        for entry in entries:
            print(
                "[MAPPINGS] "
                f"{entry.client_id}/{entry.client_virtual_ip} "
                f"{entry.protocol} "
                f"{entry.source_ip}:{entry.source_port} -> "
                f"{entry.destination_ip}:{entry.destination_port} "
                f"sid={entry.session_id} packets={entry.packet_count} "
                f"age={now - entry.first_seen:.0f}s "
                f"idle={now - entry.last_seen:.0f}s"
            )


class ServerNetworkManager:
    def __init__(self, tun_name: str, outbound_interface: str | None) -> None:
        self.tun_name = tun_name
        self.outbound_interface = outbound_interface
        self._added_rules: list[tuple[str | None, str, list[str]]] = []
        self._previous_ip_forward: str | None = None
        self._changed_ip_forward = False

    def _detect_outbound_interface(self) -> str:
        result = run_network_command(["ip", "-4", "route", "show", "default"])
        default_line = next(
            (line for line in result.stdout.splitlines() if line.strip()), ""
        )
        match = re.search(r"\bdev\s+(\S+)", default_line)
        if not match:
            raise RuntimeError(
                "could not determine the outbound interface; pass --outbound-interface"
            )
        return match.group(1)

    def _iptables_prefix(self, table: str | None) -> list[str]:
        prefix = ["iptables", "-w"]
        if table is not None:
            prefix.extend(["-t", table])
        return prefix

    def _add_rule(
        self, table: str | None, chain: str, rule: list[str]
    ) -> None:
        prefix = self._iptables_prefix(table)
        check = run_network_command(
            [*prefix, "-C", chain, *rule], check=False
        )
        if check.returncode == 0:
            return
        run_network_command([*prefix, "-A", chain, *rule])
        self._added_rules.append((table, chain, rule))

    def setup(self) -> str:
        outbound = self.outbound_interface or self._detect_outbound_interface()
        try:
            current = run_network_command(
                ["sysctl", "-n", "net.ipv4.ip_forward"]
            ).stdout.strip()
            self._previous_ip_forward = current
            if current != "1":
                run_network_command(
                    ["sysctl", "-w", "net.ipv4.ip_forward=1"]
                )
                self._changed_ip_forward = True

            self._add_rule(
                "nat",
                "POSTROUTING",
                [
                    "-s",
                    VPN_SUBNET,
                    "-o",
                    outbound,
                    "-j",
                    "MASQUERADE",
                ],
            )
            self._add_rule(
                None,
                "FORWARD",
                [
                    "-i",
                    self.tun_name,
                    "-o",
                    outbound,
                    "-s",
                    VPN_SUBNET,
                    "-j",
                    "ACCEPT",
                ],
            )
            self._add_rule(
                None,
                "FORWARD",
                [
                    "-i",
                    outbound,
                    "-o",
                    self.tun_name,
                    "-d",
                    VPN_SUBNET,
                    "-m",
                    "conntrack",
                    "--ctstate",
                    "ESTABLISHED,RELATED",
                    "-j",
                    "ACCEPT",
                ],
            )
            return outbound
        except Exception:
            self.cleanup()
            raise

    def cleanup(self) -> None:
        for table, chain, rule in reversed(self._added_rules):
            run_network_command(
                [*self._iptables_prefix(table), "-D", chain, *rule],
                check=False,
            )
        self._added_rules.clear()
        if self._changed_ip_forward and self._previous_ip_forward is not None:
            run_network_command(
                [
                    "sysctl",
                    "-w",
                    f"net.ipv4.ip_forward={self._previous_ip_forward}",
                ],
                check=False,
            )
            self._changed_ip_forward = False


class VPNServer:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.repository = Repository(args.database)
        self.repository.initialize()
        self.repository.ensure_user(
            args.admin_username,
            args.admin_password,
            role="admin",
            quota_bytes=0,
        )
        if args.demo_username and args.demo_password:
            self.repository.ensure_user(
                args.demo_username,
                args.demo_password,
                quota_bytes=args.demo_quota,
                upload_rate_bps=args.demo_upload_rate,
                download_rate_bps=args.demo_download_rate,
            )
        self.auth = AuthService(self.repository)
        self.accounting = AccountingService(self.repository)
        self.firewall = FirewallEngine(self.repository)
        self.dns = DNSMonitor()
        self.stop_event = threading.Event()
        self.manager = ClientManager()
        self.mappings = PortMappingTable()
        self.tun: TunDevice | None = None
        self.network: ServerNetworkManager | None = None
        self.listener: socket.socket | None = None
        self.status_listener: socket.socket | None = None
        self.tun_write_lock = threading.Lock()
        self._sockets: set[socket.socket] = set()
        self._sockets_lock = threading.Lock()
        self._threads: list[threading.Thread] = []
        self._cleanup_lock = threading.Lock()
        self._cleaned = False

    def _make_listener(self, bind: str, port: int, backlog: int) -> socket.socket:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((bind, port))
        listener.listen(backlog)
        listener.settimeout(1.0)
        return listener

    def _start_thread(self, target: object, name: str) -> None:
        thread = threading.Thread(target=target, name=name, daemon=True)
        thread.start()
        self._threads.append(thread)

    def _track_socket(self, sock: socket.socket) -> None:
        with self._sockets_lock:
            self._sockets.add(sock)

    def _untrack_socket(self, sock: socket.socket) -> None:
        with self._sockets_lock:
            self._sockets.discard(sock)

    def run(self) -> None:
        try:
            self.tun = create_tun(self.args.tun_name)
            configure_tun(
                self.tun.name, SERVER_TUN_IP_CIDR, self.args.mtu
            )
            self.network = ServerNetworkManager(
                self.tun.name, self.args.outbound_interface
            )
            outbound = self.network.setup()
            print(
                f"[SERVER] {self.tun.name}={SERVER_TUN_IP_CIDR}; "
                f"forwarding/NAT outbound on {outbound}"
            )

            self.listener = self._make_listener(self.args.bind, self.args.port, 100)
            self.status_listener = self._make_listener(
                self.args.status_bind, self.args.status_port, 10
            )
            self._start_thread(self.tun_reader_loop, "tun-reader")
            self._start_thread(self.heartbeat_loop, "heartbeats")
            self._start_thread(self.status_api_loop, "status-api")
            self._start_thread(self.mapping_loop, "mapping-cleanup")
            self._start_thread(self.accounting_loop, "accounting")
            self._start_thread(self.web_loop, "web-dashboard")

            print(
                f"[SERVER] VPN listening on {self.args.bind}:{self.args.port}; "
                f"status on {self.args.status_bind}:{self.args.status_port}; "
                f"web on {self.args.web_bind}:{self.args.web_port}"
            )
            while not self.stop_event.is_set():
                try:
                    sock, address = self.listener.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if self.stop_event.is_set():
                        break
                    raise
                self._track_socket(sock)
                thread = threading.Thread(
                    target=self.handle_client,
                    args=(sock, address),
                    name=f"client-{address[0]}:{address[1]}",
                    daemon=True,
                )
                thread.start()
                self._threads.append(thread)
        finally:
            self.cleanup()

    def _receive_auth_request(
        self, sock: socket.socket, channel: CaesarChannel
    ) -> tuple[str, str, str]:
        reassembler = Reassembler()
        while True:
            message = Message.decode(channel.decrypt(recv_frame(sock)))
            complete = reassembler.add(message)
            if complete is None:
                continue
            msg_type, _session_id, payload = complete
            if msg_type != MessageType.AUTH_REQUEST:
                raise ValueError("authentication is required before VPN data")
            data = json.loads(payload.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("malformed authentication request")
            username = str(data.get("username", "")).strip()
            password = str(data.get("password", ""))
            mode = str(data.get("mode", "tun")).lower()
            if not username or not password:
                raise ValueError("username and password are required")
            if mode not in {"tun", "proxy"}:
                raise ValueError("unsupported client mode")
            return username, password, mode

    @staticmethod
    def _send_auth_response(
        sock: socket.socket,
        channel: CaesarChannel,
        payload: dict[str, object],
    ) -> None:
        encoded = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        for message in make_messages(MessageType.AUTH_RESPONSE, encoded):
            send_frame(sock, channel.encrypt(message.encode()))

    def handle_client(
        self, sock: socket.socket, address: tuple[str, int]
    ) -> None:
        virtual_ip: str | None = None
        claimed_client_id: str | None = None
        connection: ClientConnection | None = None
        registered = False

        def claim_client_id(client_id: str) -> bool:
            nonlocal claimed_client_id
            accepted = self.manager.claim_client_id(client_id)
            if accepted:
                claimed_client_id = client_id
            return accepted

        try:
            sock.settimeout(10.0)
            channel, client_id = server_channel_handshake(
                sock, self.args.psk, client_id_validator=claim_client_id
            )
            username, password, mode = self._receive_auth_request(sock, channel)
            user, reason = self.auth.authenticate_vpn(username, password)
            if user is None:
                self._send_auth_response(sock, channel, {"ok": False, "error": reason})
                return

            virtual_ip = self.manager.reserve_ip()
            self.accounting.register(user)
            db_session_id = self.repository.create_vpn_session(
                user.id, client_id, address[0], address[1], virtual_ip
            )
            connection = ClientConnection(
                sock=sock,
                address=address,
                channel=channel,
                client_id=client_id,
                virtual_ip=virtual_ip,
                user_id=user.id,
                username=user.username,
                db_session_id=db_session_id,
                upload_limiter=TokenBucket(user.upload_rate_bps),
                download_limiter=TokenBucket(user.download_rate_bps),
                mode=mode,
            )
            self.manager.register(connection)
            registered = True
            self._send_auth_response(
                sock,
                channel,
                {
                    "ok": True,
                    "virtual_ip": virtual_ip,
                    "username": user.username,
                    "mode": mode,
                },
            )
            sock.settimeout(None)
            if mode == "tun":
                self._start_thread(
                    lambda: self.download_sender_loop(connection),
                    f"sender-{client_id}",
                )
            print(
                f"[SERVER] connected user={user.username} id={client_id} "
                f"real={address[0]}:{address[1]} virtual={virtual_ip} "
                f"mode={mode} active={self.manager.count()}"
            )

            while not self.stop_event.is_set() and not connection.closed.is_set():
                encrypted = recv_frame(sock)
                message = Message.decode(channel.decrypt(encrypted))
                reassembled = connection.reassembler.add(message)
                if reassembled is None:
                    continue
                msg_type, session_id, payload = reassembled
                connection.last_peer_alive = time.monotonic()

                if msg_type == MessageType.DATA:
                    if connection.mode != "tun":
                        connection.close("protocol_error")
                        break
                    self._handle_outgoing_packet(connection, session_id, payload)
                elif msg_type == MessageType.PROXY_CONNECT:
                    if connection.mode != "proxy":
                        connection.close("protocol_error")
                        break
                    self._handle_proxy_connect(connection, session_id, payload)
                elif msg_type == MessageType.PROXY_DATA:
                    if connection.mode != "proxy":
                        connection.close("protocol_error")
                        break
                    self._handle_proxy_data(connection, session_id, payload)
                elif msg_type == MessageType.PROXY_CLOSE:
                    if connection.mode != "proxy":
                        connection.close("protocol_error")
                        break
                    self._close_proxy_stream(connection, session_id, notify=False)
                elif msg_type == MessageType.HEARTBEAT:
                    connection.mark_peer_alive()
                    connection.send_message(MessageType.HEARTBEAT_ACK)
                elif msg_type == MessageType.HEARTBEAT_ACK:
                    connection.mark_peer_alive()
                elif msg_type == MessageType.CLOSE:
                    connection.close("client_close")
                    break
                elif msg_type in {MessageType.AUTH_REQUEST, MessageType.AUTH_RESPONSE}:
                    connection.close("protocol_error")
                    break
        except Exception as exc:
            if connection is not None and not connection.closed.is_set():
                connection.close("error")
            if not self.stop_event.is_set():
                print(f"[SERVER] connection {address} ended: {exc}")
        finally:
            if connection is not None:
                connection.close(connection.disconnect_reason)
                self.mappings.remove_client(connection.client_id)
                self.manager.unregister(connection)
                try:
                    self.accounting.flush_user(connection.user_id)
                    self.repository.close_vpn_session(
                        connection.db_session_id,
                        connection.bytes_received,
                        connection.bytes_sent,
                        connection.disconnect_reason,
                    )
                except Exception as exc:
                    print(f"[ACCOUNTING] final flush failed: {exc}")
            else:
                self.manager.release_pending(virtual_ip, claimed_client_id)
                try:
                    sock.close()
                except OSError:
                    pass
            self._untrack_socket(sock)
            if registered and connection is not None:
                print(
                    f"[SERVER] disconnected user={connection.username} "
                    f"id={connection.client_id} reason={connection.disconnect_reason} "
                    f"active={self.manager.count()}"
                )

    @staticmethod
    def _proxy_response(ok: bool, error: str | None = None) -> bytes:
        result: dict[str, object] = {"ok": ok}
        if error:
            result["error"] = error
        return json.dumps(result, separators=(",", ":")).encode("utf-8")

    def _handle_proxy_connect(
        self, connection: ClientConnection, stream_id: int, payload: bytes
    ) -> None:
        if stream_id == 0:
            connection.send_message(
                MessageType.PROXY_CONNECTED,
                self._proxy_response(False, "invalid proxy stream ID"),
                stream_id,
            )
            return
        with connection.proxy_lock:
            if stream_id in connection.proxy_sockets:
                connection.send_message(
                    MessageType.PROXY_CONNECTED,
                    self._proxy_response(False, "proxy stream already exists"),
                    stream_id,
                )
                return

        try:
            request = json.loads(payload.decode("utf-8"))
            if not isinstance(request, dict):
                raise ValueError("malformed proxy request")
            host = str(request.get("host", "")).strip()
            port = int(request.get("port", 0))
            if not host or len(host) > 253 or not 1 <= port <= 65535:
                raise ValueError("invalid proxy destination")

            addresses = socket.getaddrinfo(
                host, port, type=socket.SOCK_STREAM
            )
            if not addresses:
                raise OSError("destination did not resolve")
            family, socktype, protocol, _canonical, socket_address = addresses[0]
            destination_ip = str(socket_address[0])
            try:
                ipaddress.ip_address(host)
                domain = None
            except ValueError:
                domain = host.rstrip(".").lower()

            flow = Flow(
                protocol=6,
                source_ip=connection.virtual_ip,
                source_port=0,
                destination_ip=destination_ip,
                destination_port=port,
            )
            decision = self.firewall.evaluate(connection.user_id, flow, domain)
            if not decision.allowed:
                self.repository.log_firewall_block(
                    rule_id=decision.rule_id,
                    user_id=connection.user_id,
                    username=connection.username,
                    destination_ip=destination_ip,
                    destination_port=port,
                    protocol="TCP",
                    domain=domain,
                )
                self.repository.log_traffic(
                    user_id=connection.user_id,
                    session_id=connection.db_session_id,
                    username=connection.username,
                    virtual_ip=connection.virtual_ip,
                    destination_ip=destination_ip,
                    destination_port=port,
                    protocol="TCP",
                    domain=domain,
                    firewall_result="block",
                )
                connection.send_message(
                    MessageType.PROXY_CONNECTED,
                    self._proxy_response(False, "blocked by VPN firewall"),
                    stream_id,
                )
                return

            target_sock = socket.socket(family, socktype, protocol)
            target_sock.settimeout(10.0)
            try:
                target_sock.connect(socket_address)
            except Exception:
                target_sock.close()
                raise
            target_sock.settimeout(None)
            with connection.proxy_lock:
                if connection.closed.is_set() or stream_id in connection.proxy_sockets:
                    target_sock.close()
                    raise ConnectionError("proxy connection is closing")
                connection.proxy_sockets[stream_id] = target_sock

            self.repository.log_traffic(
                user_id=connection.user_id,
                session_id=connection.db_session_id,
                username=connection.username,
                virtual_ip=connection.virtual_ip,
                destination_ip=destination_ip,
                destination_port=port,
                protocol="TCP",
                domain=domain,
                firewall_result="allow",
            )
            self.mappings.update(
                connection.client_id,
                connection.virtual_ip,
                flow,
                stream_id,
            )
            connection.send_message(
                MessageType.PROXY_CONNECTED,
                self._proxy_response(True),
                stream_id,
            )
            self._start_thread(
                lambda: self._proxy_reader_loop(
                    connection, stream_id, target_sock
                ),
                f"proxy-{connection.client_id}-{stream_id}",
            )
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            try:
                connection.send_message(
                    MessageType.PROXY_CONNECTED,
                    self._proxy_response(False, str(exc)[:160]),
                    stream_id,
                )
            except (ConnectionError, OSError):
                pass

    def _handle_proxy_data(
        self, connection: ClientConnection, stream_id: int, payload: bytes
    ) -> None:
        with connection.proxy_lock:
            target_sock = connection.proxy_sockets.get(stream_id)
        if target_sock is None:
            try:
                connection.send_message(MessageType.PROXY_CLOSE, b"", stream_id)
            except (ConnectionError, OSError):
                pass
            return
        if not connection.upload_limiter.wait(len(payload), connection.closed):
            return
        if not self.accounting.consume(connection.user_id, "upload", len(payload)):
            try:
                connection.send_message(MessageType.QUOTA_EXHAUSTED)
            except (ConnectionError, OSError):
                pass
            connection.close("quota_exhausted")
            return
        try:
            target_sock.sendall(payload)
            connection.bytes_received += len(payload)
        except OSError:
            self._close_proxy_stream(connection, stream_id, notify=True)

    def _proxy_reader_loop(
        self,
        connection: ClientConnection,
        stream_id: int,
        target_sock: socket.socket,
    ) -> None:
        try:
            while not self.stop_event.is_set() and not connection.closed.is_set():
                payload = target_sock.recv(65535)
                if not payload:
                    break
                if not connection.download_limiter.wait(
                    len(payload), connection.closed
                ):
                    return
                if not self.accounting.consume(
                    connection.user_id, "download", len(payload)
                ):
                    try:
                        connection.send_message(MessageType.QUOTA_EXHAUSTED)
                    except (ConnectionError, OSError):
                        pass
                    connection.close("quota_exhausted")
                    return
                connection.send_message(
                    MessageType.PROXY_DATA, payload, stream_id
                )
                connection.bytes_sent += len(payload)
        except (ConnectionError, OSError):
            pass
        finally:
            self._close_proxy_stream(connection, stream_id, notify=True)

    @staticmethod
    def _close_proxy_stream(
        connection: ClientConnection, stream_id: int, notify: bool
    ) -> None:
        with connection.proxy_lock:
            target_sock = connection.proxy_sockets.pop(stream_id, None)
        if target_sock is None:
            return
        try:
            target_sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            target_sock.close()
        except OSError:
            pass
        if notify and not connection.closed.is_set():
            try:
                connection.send_message(MessageType.PROXY_CLOSE, b"", stream_id)
            except (ConnectionError, OSError):
                pass

    def _handle_outgoing_packet(
        self, connection: ClientConnection, session_id: int, payload: bytes
    ) -> None:
        try:
            flow = parse_ipv4(payload)
        except ValueError as exc:
            print(f"[SERVER] dropped malformed packet from {connection.client_id}: {exc}")
            return
        if flow.source_ip != connection.virtual_ip:
            print(
                f"[SERVER] dropped spoofed source {flow.source_ip} "
                f"from {connection.client_id}"
            )
            return
        if not connection.upload_limiter.wait(len(payload), connection.closed):
            return
        if not self.accounting.consume(connection.user_id, "upload", len(payload)):
            try:
                connection.send_message(MessageType.QUOTA_EXHAUSTED)
            except (ConnectionError, OSError):
                pass
            connection.close("quota_exhausted")
            return
        connection.bytes_received += len(payload)

        domain = self.dns.observe_outgoing(connection.user_id, payload)
        if domain is None:
            domain = self.dns.lookup(connection.user_id, flow.destination_ip)
        decision = self.firewall.evaluate(connection.user_id, flow, domain)
        if not decision.allowed:
            self.repository.log_firewall_block(
                rule_id=decision.rule_id,
                user_id=connection.user_id,
                username=connection.username,
                destination_ip=flow.destination_ip,
                destination_port=flow.destination_port,
                protocol=flow.protocol_name,
                domain=domain,
            )
            self.repository.log_traffic(
                user_id=connection.user_id,
                session_id=connection.db_session_id,
                username=connection.username,
                virtual_ip=connection.virtual_ip,
                destination_ip=flow.destination_ip,
                destination_port=flow.destination_port,
                protocol=flow.protocol_name,
                domain=domain,
                firewall_result="block",
            )
            return

        new_flow = True
        if flow.protocol in (6, 17):
            new_flow = self.mappings.update(
                connection.client_id, connection.virtual_ip, flow, session_id
            )
        if new_flow:
            self.repository.log_traffic(
                user_id=connection.user_id,
                session_id=connection.db_session_id,
                username=connection.username,
                virtual_ip=connection.virtual_ip,
                destination_ip=flow.destination_ip,
                destination_port=flow.destination_port,
                protocol=flow.protocol_name,
                domain=domain,
                firewall_result="allow",
            )
        assert self.tun is not None
        with self.tun_write_lock:
            os.write(self.tun.fd, payload)

    def tun_reader_loop(self) -> None:
        assert self.tun is not None
        while not self.stop_event.is_set():
            try:
                readable, _, _ = select.select(
                    [self.tun.fd], [], [], 1.0
                )
                if not readable:
                    continue
                packet = os.read(self.tun.fd, 65535)
            except (OSError, ValueError):
                break
            try:
                flow = parse_ipv4(packet)
            except ValueError as exc:
                print(f"[SERVER] ignored malformed TUN packet: {exc}")
                continue
            connection = self.manager.get_by_ip(flow.destination_ip)
            if connection is None:
                continue
            try:
                self.dns.observe_incoming(connection.user_id, packet)
                connection.download_queue.put_nowait((packet, flow.session_id))
            except queue.Full:
                connection.close("download_queue_overflow")

    def download_sender_loop(self, connection: ClientConnection) -> None:
        while not self.stop_event.is_set() and not connection.closed.is_set():
            try:
                packet, session_id = connection.download_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if not connection.download_limiter.wait(len(packet), connection.closed):
                return
            if not self.accounting.consume(
                connection.user_id, "download", len(packet)
            ):
                try:
                    connection.send_message(MessageType.QUOTA_EXHAUSTED)
                except (ConnectionError, OSError):
                    pass
                connection.close("quota_exhausted")
                return
            try:
                connection.send_message(MessageType.DATA, packet, session_id)
                connection.bytes_sent += len(packet)
            except (ConnectionError, OSError):
                connection.close("send_error")
                return

    def heartbeat_loop(self) -> None:
        while not self.stop_event.wait(HEARTBEAT_INTERVAL):
            now = time.monotonic()
            for connection in self.manager.snapshot():
                if now - connection.last_peer_alive > HEARTBEAT_TIMEOUT:
                    print(
                        f"[SERVER] heartbeat timeout for "
                        f"{connection.client_id}"
                    )
                    connection.close("heartbeat_timeout")
                    continue
                try:
                    connection.send_message(MessageType.HEARTBEAT)
                except (ConnectionError, OSError):
                    connection.close("heartbeat_send_error")

    def accounting_loop(self) -> None:
        while not self.stop_event.wait(self.args.accounting_interval):
            try:
                self.accounting.flush_all()
                for connection in self.manager.snapshot():
                    self.repository.update_vpn_session_totals(
                        connection.db_session_id,
                        connection.bytes_received,
                        connection.bytes_sent,
                    )
            except Exception as exc:
                print(f"[ACCOUNTING] periodic flush failed: {exc}")

    def web_loop(self) -> None:
        from web_app import create_app

        app = create_app(self, self.repository, self.args.web_secret)
        app.run(
            host=self.args.web_bind,
            port=self.args.web_port,
            threaded=True,
            use_reloader=False,
        )

    def status_api_loop(self) -> None:
        assert self.status_listener is not None
        while not self.stop_event.is_set():
            try:
                sock, _ = self.status_listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with sock:
                clients = [
                    connection.status()
                    for connection in self.manager.snapshot()
                ]
                payload = {
                    "ok": True,
                    "connected_clients": len(clients),
                    "vpn_port": self.args.port,
                    "clients": clients,
                }
                try:
                    sock.sendall(
                        json.dumps(payload, separators=(",", ":")).encode(
                            "utf-8"
                        )
                        + b"\n"
                    )
                except OSError:
                    pass

    def mapping_loop(self) -> None:
        while not self.stop_event.wait(self.args.mapping_interval):
            removed = self.mappings.expire_stale(
                self.args.mapping_timeout
            )
            if removed:
                print(f"[MAPPINGS] expired {removed} stale flow(s)")
            if self.args.show_mappings:
                self.mappings.print_compact()

    def request_stop(self) -> None:
        if self.stop_event.is_set():
            return
        self.stop_event.set()
        for listener in (self.listener, self.status_listener):
            if listener is not None:
                try:
                    listener.close()
                except OSError:
                    pass
        with self._sockets_lock:
            sockets = list(self._sockets)
        for sock in sockets:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        for connection in self.manager.snapshot():
            connection.close("server_shutdown")
        if self.tun is not None:
            self.tun.close()

    def cleanup(self) -> None:
        with self._cleanup_lock:
            if self._cleaned:
                return
            self._cleaned = True
        self.request_stop()
        current = threading.current_thread()
        for thread in self._threads:
            if thread is not current:
                thread.join(timeout=1.0)
        for connection in self.manager.snapshot():
            self.mappings.remove_client(connection.client_id)
            self.manager.unregister(connection)
        try:
            self.accounting.flush_all()
        except Exception as exc:
            print(f"[ACCOUNTING] shutdown flush failed: {exc}")
        if self.network is not None:
            try:
                self.network.cleanup()
            except Exception as exc:
                print(f"[SERVER] network cleanup warning: {exc}")
        print("[SERVER] shutdown complete")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Layer-3 TUN VPN server")
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--status-bind", default="0.0.0.0")
    parser.add_argument("--status-port", type=int, default=DEFAULT_STATUS_PORT)
    parser.add_argument("--psk", default=DEFAULT_PSK)
    parser.add_argument("--database", default="data/vpn.db")
    parser.add_argument("--web-bind", default="0.0.0.0")
    parser.add_argument("--web-port", type=int, default=8080)
    parser.add_argument(
        "--web-secret",
        default=os.environ.get("VPN_WEB_SECRET") or os.urandom(32).hex(),
    )
    parser.add_argument(
        "--admin-username", default=os.environ.get("VPN_ADMIN_USERNAME", "admin")
    )
    parser.add_argument(
        "--admin-password", default=os.environ.get("VPN_ADMIN_PASSWORD", "admin123")
    )
    parser.add_argument(
        "--demo-username", default=os.environ.get("VPN_DEMO_USERNAME", "alice")
    )
    parser.add_argument(
        "--demo-password", default=os.environ.get("VPN_DEMO_PASSWORD", "alice123")
    )
    parser.add_argument("--demo-quota", type=int, default=100 * 1024 * 1024)
    parser.add_argument("--demo-upload-rate", type=int, default=512 * 1024)
    parser.add_argument("--demo-download-rate", type=int, default=1024 * 1024)
    parser.add_argument("--tun-name", default="tun0")
    parser.add_argument("--mtu", type=int, default=DEFAULT_TUN_MTU)
    parser.add_argument(
        "--outbound-interface",
        help="physical interface for forwarding; default is auto-detected",
    )
    parser.add_argument(
        "--show-mappings",
        action="store_true",
        help="print the application flow table periodically",
    )
    parser.add_argument("--mapping-interval", type=float, default=20.0)
    parser.add_argument("--mapping-timeout", type=float, default=120.0)
    parser.add_argument("--accounting-interval", type=float, default=2.0)
    args = parser.parse_args()
    if min(args.mapping_interval, args.mapping_timeout, args.accounting_interval) <= 0:
        parser.error("mapping and accounting intervals must be positive")
    if not 1 <= args.web_port <= 65535:
        parser.error("web port must be between 1 and 65535")
    return args


def main() -> None:
    args = parse_args()
    server = VPNServer(args)
    signal.signal(signal.SIGINT, lambda _signum, _frame: server.request_stop())
    signal.signal(signal.SIGTERM, lambda _signum, _frame: server.request_stop())
    try:
        server.run()
    except Exception as exc:
        print(f"[SERVER] fatal error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
