from __future__ import annotations

import hashlib
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from werkzeug.security import check_password_hash, generate_password_hash


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Repository:
    """Short-lived, thread-safe SQLite access for VPN and web workers."""

    def __init__(self, path: str) -> None:
        self.path = str(Path(path).expanduser().resolve())

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=5.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 5000")
        try:
            yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("PRAGMA synchronous = NORMAL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'user'
                        CHECK (role IN ('user', 'admin')),
                    status TEXT NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active', 'blocked', 'quota_exhausted')),
                    quota_bytes INTEGER NOT NULL CHECK (quota_bytes >= 0),
                    used_bytes INTEGER NOT NULL DEFAULT 0 CHECK (used_bytes >= 0),
                    total_upload_bytes INTEGER NOT NULL DEFAULT 0
                        CHECK (total_upload_bytes >= 0),
                    total_download_bytes INTEGER NOT NULL DEFAULT 0
                        CHECK (total_download_bytes >= 0),
                    upload_rate_bps INTEGER NOT NULL DEFAULT 0
                        CHECK (upload_rate_bps >= 0),
                    download_rate_bps INTEGER NOT NULL DEFAULT 0
                        CHECK (download_rate_bps >= 0),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS vpn_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id),
                    client_id TEXT NOT NULL,
                    real_ip TEXT NOT NULL,
                    real_port INTEGER NOT NULL,
                    virtual_ip TEXT NOT NULL,
                    connected_at TEXT NOT NULL,
                    disconnected_at TEXT,
                    upload_bytes INTEGER NOT NULL DEFAULT 0,
                    download_bytes INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active', 'closed')),
                    disconnect_reason TEXT
                );

                CREATE TABLE IF NOT EXISTS traffic_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id),
                    session_id INTEGER REFERENCES vpn_sessions(id),
                    username TEXT NOT NULL,
                    virtual_ip TEXT NOT NULL,
                    destination_ip TEXT NOT NULL,
                    destination_port INTEGER NOT NULL,
                    protocol TEXT NOT NULL,
                    domain TEXT,
                    firewall_result TEXT NOT NULL
                        CHECK (firewall_result IN ('allow', 'block')),
                    observed_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS firewall_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                    destination_ip TEXT,
                    destination_port INTEGER,
                    protocol TEXT,
                    domain TEXT,
                    action TEXT NOT NULL CHECK (action IN ('accept', 'block')),
                    priority INTEGER NOT NULL DEFAULT 100,
                    enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
                    created_at TEXT NOT NULL,
                    CHECK (destination_port IS NULL OR
                           destination_port BETWEEN 0 AND 65535)
                );

                CREATE TABLE IF NOT EXISTS firewall_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rule_id INTEGER REFERENCES firewall_rules(id) ON DELETE SET NULL,
                    user_id INTEGER NOT NULL REFERENCES users(id),
                    username TEXT NOT NULL,
                    destination_ip TEXT NOT NULL,
                    destination_port INTEGER NOT NULL,
                    protocol TEXT NOT NULL,
                    domain TEXT,
                    blocked_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS quota_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id),
                    requested_bytes INTEGER NOT NULL CHECK (requested_bytes > 0),
                    status TEXT NOT NULL DEFAULT 'approved'
                        CHECK (status IN ('pending', 'approved', 'rejected')),
                    requested_at TEXT NOT NULL,
                    decided_at TEXT
                );

                CREATE TABLE IF NOT EXISTS web_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    token_hash TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    revoked_at TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_vpn_sessions_user
                    ON vpn_sessions(user_id, connected_at DESC);
                CREATE INDEX IF NOT EXISTS idx_traffic_user_time
                    ON traffic_log(user_id, observed_at DESC);
                CREATE INDEX IF NOT EXISTS idx_firewall_scope
                    ON firewall_rules(user_id, enabled, priority DESC);
                CREATE INDEX IF NOT EXISTS idx_web_sessions_token
                    ON web_sessions(token_hash, expires_at);
                """
            )
            connection.commit()

    @staticmethod
    def _dict(row: sqlite3.Row | None) -> dict[str, object] | None:
        return None if row is None else dict(row)

    def create_user(
        self,
        username: str,
        password: str,
        *,
        role: str = "user",
        quota_bytes: int = 1024 * 1024 * 1024,
        upload_rate_bps: int = 0,
        download_rate_bps: int = 0,
    ) -> int:
        username = username.strip()
        if not username or len(username) > 64:
            raise ValueError("username must be 1 to 64 characters")
        if len(password) < 6:
            raise ValueError("password must be at least 6 characters")
        if role not in {"user", "admin"}:
            raise ValueError("role must be user or admin")
        if min(quota_bytes, upload_rate_bps, download_rate_bps) < 0:
            raise ValueError("quota and rate limits cannot be negative")
        now = utc_now()
        with self.connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO users (
                    username, password_hash, role, status, quota_bytes,
                    upload_rate_bps, download_rate_bps, created_at, updated_at
                ) VALUES (?, ?, ?, 'active', ?, ?, ?, ?, ?)
                """,
                (
                    username,
                    generate_password_hash(password),
                    role,
                    quota_bytes,
                    upload_rate_bps,
                    download_rate_bps,
                    now,
                    now,
                ),
            )
            connection.commit()
            return int(cursor.lastrowid)

    def ensure_user(self, username: str, password: str, **kwargs: object) -> int:
        existing = self.get_user_by_username(username)
        if existing is not None:
            return int(existing["id"])
        return self.create_user(username, password, **kwargs)

    def authenticate(self, username: str, password: str) -> dict[str, object] | None:
        user = self.get_user_by_username(username)
        if user is None or not check_password_hash(str(user["password_hash"]), password):
            return None
        return user

    def authorize_vpn(
        self, username: str, password: str
    ) -> tuple[dict[str, object] | None, str]:
        user = self.authenticate(username, password)
        if user is None:
            return None, "invalid username or password"
        if user["role"] == "admin":
            return None, "administrator accounts cannot open VPN tunnels"
        if user["status"] == "blocked":
            return None, "account is blocked"
        if int(user["used_bytes"]) >= int(user["quota_bytes"]):
            self.mark_quota_exhausted(int(user["id"]))
            return None, "traffic quota is exhausted"
        if user["status"] == "quota_exhausted":
            return None, "traffic quota is exhausted"
        return user, "ok"

    def get_user(self, user_id: int) -> dict[str, object] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM users WHERE id = ?", (user_id,)
            ).fetchone()
        return self._dict(row)

    def get_user_by_username(self, username: str) -> dict[str, object] | None:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM users WHERE username = ? COLLATE NOCASE",
                (username.strip(),),
            ).fetchone()
        return self._dict(row)

    def list_users(self) -> list[dict[str, object]]:
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM users ORDER BY role DESC, username COLLATE NOCASE"
            ).fetchall()
        return [dict(row) for row in rows]

    def set_user_status(self, user_id: int, status: str) -> None:
        if status not in {"active", "blocked", "quota_exhausted"}:
            raise ValueError("invalid user status")
        with self.connect() as connection:
            connection.execute(
                "UPDATE users SET status = ?, updated_at = ? WHERE id = ?",
                (status, utc_now(), user_id),
            )
            connection.commit()

    def mark_quota_exhausted(self, user_id: int) -> None:
        self.set_user_status(user_id, "quota_exhausted")

    def update_user_limits(
        self,
        user_id: int,
        *,
        quota_bytes: int,
        upload_rate_bps: int,
        download_rate_bps: int,
    ) -> None:
        if min(quota_bytes, upload_rate_bps, download_rate_bps) < 0:
            raise ValueError("limits cannot be negative")
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE users
                SET quota_bytes = ?, upload_rate_bps = ?, download_rate_bps = ?,
                    status = CASE
                        WHEN status = 'quota_exhausted' AND used_bytes < ?
                            THEN 'active'
                        ELSE status
                    END,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    quota_bytes,
                    upload_rate_bps,
                    download_rate_bps,
                    quota_bytes,
                    utc_now(),
                    user_id,
                ),
            )
            connection.commit()

    def add_usage(self, user_id: int, upload: int, download: int) -> dict[str, object]:
        if upload < 0 or download < 0:
            raise ValueError("usage deltas cannot be negative")
        with self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                UPDATE users
                SET used_bytes = used_bytes + ?,
                    total_upload_bytes = total_upload_bytes + ?,
                    total_download_bytes = total_download_bytes + ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (upload + download, upload, download, utc_now(), user_id),
            )
            row = connection.execute(
                "SELECT * FROM users WHERE id = ?", (user_id,)
            ).fetchone()
            connection.commit()
        if row is None:
            raise KeyError(f"unknown user id {user_id}")
        return dict(row)

    def purchase_quota(self, user_id: int, requested_bytes: int) -> int:
        if requested_bytes <= 0:
            raise ValueError("requested quota must be positive")
        now = utc_now()
        with self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cursor = connection.execute(
                """
                INSERT INTO quota_requests (
                    user_id, requested_bytes, status, requested_at, decided_at
                ) VALUES (?, ?, 'approved', ?, ?)
                """,
                (user_id, requested_bytes, now, now),
            )
            connection.execute(
                """
                UPDATE users
                SET quota_bytes = quota_bytes + ?,
                    status = CASE
                        WHEN status = 'quota_exhausted' THEN 'active'
                        ELSE status
                    END,
                    updated_at = ?
                WHERE id = ?
                """,
                (requested_bytes, now, user_id),
            )
            connection.commit()
            return int(cursor.lastrowid)

    def list_quota_requests(self, user_id: int) -> list[dict[str, object]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM quota_requests
                WHERE user_id = ? ORDER BY requested_at DESC
                """,
                (user_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def create_vpn_session(
        self,
        user_id: int,
        client_id: str,
        real_ip: str,
        real_port: int,
        virtual_ip: str,
    ) -> int:
        with self.connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO vpn_sessions (
                    user_id, client_id, real_ip, real_port, virtual_ip, connected_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (user_id, client_id, real_ip, real_port, virtual_ip, utc_now()),
            )
            connection.commit()
            return int(cursor.lastrowid)

    def update_vpn_session_totals(
        self, session_id: int, upload_bytes: int, download_bytes: int
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE vpn_sessions
                SET upload_bytes = ?, download_bytes = ?
                WHERE id = ? AND status = 'active'
                """,
                (upload_bytes, download_bytes, session_id),
            )
            connection.commit()

    def close_vpn_session(
        self,
        session_id: int,
        upload_bytes: int,
        download_bytes: int,
        reason: str,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                UPDATE vpn_sessions
                SET disconnected_at = ?, upload_bytes = ?, download_bytes = ?,
                    status = 'closed', disconnect_reason = ?
                WHERE id = ?
                """,
                (utc_now(), upload_bytes, download_bytes, reason[:120], session_id),
            )
            connection.commit()

    def list_vpn_sessions(self, limit: int = 200) -> list[dict[str, object]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT s.*, u.username
                FROM vpn_sessions AS s JOIN users AS u ON u.id = s.user_id
                ORDER BY s.id DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def log_traffic(
        self,
        *,
        user_id: int,
        session_id: int,
        username: str,
        virtual_ip: str,
        destination_ip: str,
        destination_port: int,
        protocol: str,
        domain: str | None,
        firewall_result: str,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                INSERT INTO traffic_log (
                    user_id, session_id, username, virtual_ip, destination_ip,
                    destination_port, protocol, domain, firewall_result, observed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    session_id,
                    username,
                    virtual_ip,
                    destination_ip,
                    destination_port,
                    protocol,
                    domain,
                    firewall_result,
                    utc_now(),
                ),
            )
            connection.commit()

    def list_traffic(self, limit: int = 300) -> list[dict[str, object]]:
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM traffic_log ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(row) for row in rows]

    def add_firewall_rule(
        self,
        *,
        user_id: int | None,
        destination_ip: str | None,
        destination_port: int | None,
        protocol: str | None,
        domain: str | None,
        action: str,
        priority: int,
    ) -> int:
        if action not in {"accept", "block"}:
            raise ValueError("invalid firewall action")
        with self.connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO firewall_rules (
                    user_id, destination_ip, destination_port, protocol, domain,
                    action, priority, enabled, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
                """,
                (
                    user_id,
                    destination_ip or None,
                    destination_port,
                    protocol or None,
                    domain or None,
                    action,
                    priority,
                    utc_now(),
                ),
            )
            connection.commit()
            return int(cursor.lastrowid)

    def delete_firewall_rule(self, rule_id: int) -> None:
        with self.connect() as connection:
            connection.execute("DELETE FROM firewall_rules WHERE id = ?", (rule_id,))
            connection.commit()

    def list_firewall_rules(self, enabled_only: bool = False) -> list[dict[str, object]]:
        where = "WHERE r.enabled = 1" if enabled_only else ""
        with self.connect() as connection:
            rows = connection.execute(
                f"""
                SELECT r.*, u.username
                FROM firewall_rules AS r
                LEFT JOIN users AS u ON u.id = r.user_id
                {where}
                ORDER BY (r.user_id IS NOT NULL) DESC, r.priority DESC, r.id ASC
                """
            ).fetchall()
        return [dict(row) for row in rows]

    def log_firewall_block(
        self,
        *,
        rule_id: int | None,
        user_id: int,
        username: str,
        destination_ip: str,
        destination_port: int,
        protocol: str,
        domain: str | None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                """
                INSERT INTO firewall_log (
                    rule_id, user_id, username, destination_ip, destination_port,
                    protocol, domain, blocked_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rule_id,
                    user_id,
                    username,
                    destination_ip,
                    destination_port,
                    protocol,
                    domain,
                    utc_now(),
                ),
            )
            connection.commit()

    def list_firewall_log(self, limit: int = 300) -> list[dict[str, object]]:
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM firewall_log ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(row) for row in rows]

    def create_web_session(self, user_id: int, expires_at: str) -> str:
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode("ascii")).hexdigest()
        with self.connect() as connection:
            connection.execute(
                """
                INSERT INTO web_sessions (user_id, token_hash, created_at, expires_at)
                VALUES (?, ?, ?, ?)
                """,
                (user_id, token_hash, utc_now(), expires_at),
            )
            connection.commit()
        return token

    def validate_web_session(self, token: str) -> dict[str, object] | None:
        token_hash = hashlib.sha256(token.encode("ascii", errors="ignore")).hexdigest()
        with self.connect() as connection:
            row = connection.execute(
                """
                SELECT u.*, s.id AS web_session_id, s.expires_at
                FROM web_sessions AS s JOIN users AS u ON u.id = s.user_id
                WHERE s.token_hash = ? AND s.revoked_at IS NULL
                    AND s.expires_at > ?
                """,
                (token_hash, utc_now()),
            ).fetchone()
        return self._dict(row)

    def revoke_web_session(self, token: str) -> None:
        token_hash = hashlib.sha256(token.encode("ascii", errors="ignore")).hexdigest()
        with self.connect() as connection:
            connection.execute(
                "UPDATE web_sessions SET revoked_at = ? WHERE token_hash = ?",
                (utc_now(), token_hash),
            )
            connection.commit()
