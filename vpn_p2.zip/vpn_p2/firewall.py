from __future__ import annotations

import ipaddress
import threading
from dataclasses import dataclass

from common import Flow
from database import Repository


@dataclass(frozen=True)
class FirewallDecision:
    allowed: bool
    rule_id: int | None = None
    action: str = "accept"


class FirewallEngine:
    def __init__(self, repository: Repository) -> None:
        self.repository = repository
        self._rules: list[dict[str, object]] = []
        self._lock = threading.RLock()
        self.refresh()

    def refresh(self) -> None:
        rules = self.repository.list_firewall_rules(enabled_only=True)
        with self._lock:
            self._rules = rules

    @staticmethod
    def _ip_matches(rule_ip: object, destination: str) -> bool:
        if not rule_ip:
            return True
        try:
            return ipaddress.ip_address(destination) in ipaddress.ip_network(
                str(rule_ip), strict=False
            )
        except ValueError:
            return False

    @staticmethod
    def _domain_matches(rule_domain: object, domain: str | None) -> bool:
        if not rule_domain:
            return True
        if not domain:
            return False
        expected = str(rule_domain).lower().lstrip("*.")
        actual = domain.lower().rstrip(".")
        return actual == expected or actual.endswith("." + expected)

    def evaluate(self, user_id: int, flow: Flow, domain: str | None) -> FirewallDecision:
        with self._lock:
            rules = list(self._rules)
        scoped = [rule for rule in rules if rule["user_id"] == user_id]
        global_rules = [rule for rule in rules if rule["user_id"] is None]
        for rule in [*scoped, *global_rules]:
            protocol = str(rule["protocol"] or "").upper()
            if protocol and protocol != flow.protocol_name.upper():
                continue
            if rule["destination_port"] is not None and int(
                rule["destination_port"]
            ) != flow.destination_port:
                continue
            if not self._ip_matches(rule["destination_ip"], flow.destination_ip):
                continue
            if not self._domain_matches(rule["domain"], domain):
                continue
            action = str(rule["action"])
            return FirewallDecision(action == "accept", int(rule["id"]), action)
        return FirewallDecision(True)
