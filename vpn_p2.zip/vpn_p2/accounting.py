from __future__ import annotations

import threading
from dataclasses import dataclass

from auth_service import AuthenticatedUser
from database import Repository


@dataclass
class UsageState:
    quota_bytes: int
    persisted_used: int
    pending_upload: int = 0
    pending_download: int = 0

    @property
    def effective_used(self) -> int:
        return self.persisted_used + self.pending_upload + self.pending_download


class AccountingService:
    """Shared per-user quota ledger with periodic durable flushes."""

    def __init__(self, repository: Repository) -> None:
        self.repository = repository
        self._states: dict[int, UsageState] = {}
        self._lock = threading.RLock()

    def register(self, user: AuthenticatedUser) -> None:
        with self._lock:
            state = self._states.get(user.id)
            if state is None:
                self._states[user.id] = UsageState(user.quota_bytes, user.used_bytes)
            else:
                state.quota_bytes = user.quota_bytes

    def consume(self, user_id: int, direction: str, amount: int) -> bool:
        if direction not in {"upload", "download"} or amount < 0:
            raise ValueError("invalid usage update")
        with self._lock:
            state = self._states.get(user_id)
            if state is None:
                row = self.repository.get_user(user_id)
                if row is None:
                    return False
                state = UsageState(int(row["quota_bytes"]), int(row["used_bytes"]))
                self._states[user_id] = state
            if state.effective_used + amount > state.quota_bytes:
                self.repository.mark_quota_exhausted(user_id)
                return False
            if direction == "upload":
                state.pending_upload += amount
            else:
                state.pending_download += amount
            return True

    def refresh(self, user_id: int) -> None:
        with self._lock:
            self.flush_user(user_id)
            row = self.repository.get_user(user_id)
            if row is None:
                return
            current = self._states.get(user_id)
            pending_upload = 0 if current is None else current.pending_upload
            pending_download = 0 if current is None else current.pending_download
            self._states[user_id] = UsageState(
                int(row["quota_bytes"]),
                int(row["used_bytes"]),
                pending_upload,
                pending_download,
            )

    def flush_user(self, user_id: int) -> None:
        with self._lock:
            state = self._states.get(user_id)
            if state is None:
                return
            upload = state.pending_upload
            download = state.pending_download
            if upload == 0 and download == 0:
                return
            state.pending_upload = 0
            state.pending_download = 0
        try:
            row = self.repository.add_usage(user_id, upload, download)
        except Exception:
            with self._lock:
                state = self._states.get(user_id)
                if state is not None:
                    state.pending_upload += upload
                    state.pending_download += download
            raise
        with self._lock:
            state = self._states.get(user_id)
            if state is not None:
                state.persisted_used = int(row["used_bytes"])
                state.quota_bytes = int(row["quota_bytes"])

    def flush_all(self) -> None:
        with self._lock:
            user_ids = list(self._states)
        for user_id in user_ids:
            self.flush_user(user_id)
