from __future__ import annotations

import argparse
import ipaddress
import json
import os
import re
import select
import signal
import socket
import sys
import threading
import time
from dataclasses import dataclass, field

from common import (
    DEFAULT_PORT,
    DEFAULT_PSK,
    DEFAULT_STATUS_PORT,
    DEFAULT_TUN_MTU,
    HEARTBEAT_INTERVAL,
    HEARTBEAT_TIMEOUT,
    SERVER_TUN_IP_CIDR,
    VPN_SUBNET,
    CaesarChannel,
    Flow,
    Message,
    MessageType,
    Reassembler,
    TunDevice,
    configure_tun,
    create_tun,
    make_messages,
    parse_ipv4,
    recv_frame,
    run_network_command,
    send_frame,
    server_handshake,
)


class ClientManager:
    def __init__(self, subnet: str = VPN_SUBNET) -> None:
        network = ipaddress.IPv4Network(subnet)
        self._pool = [str(address) for address in list(network.hosts())[1:]]
        self._by_ip: dict[str, ClientConnection] = {}
        self._by_id: dict[str, ClientConnection] = {}
        self._reserved_ips: set[str] = set()
        self._claimed_ids: set[str] = set()
        self._lock = threading.RLock()

    def reserve_ip(self) -> str:
        with self._lock:
            for candidate in self._pool:
                if candidate not in self._by_ip and candidate not in self._reserved_ips:
                    self._reserved_ips.add(candidate)
                    return candidate
        raise RuntimeError("virtual IP pool is exhausted")

    def claim_client_id(self, client_id: str) -> bool:
        with self._lock:
            existing = self._by_id.get(client_id)
            if existing is not None and not existing.closed.is_set():
                return False
            if client_id in self._claimed_ids:
                return False
            if existing is not None:
                self._by_id.pop(client_id, None)
                self._by_ip.pop(existing.virtual_ip, None)
            self._claimed_ids.add(client_id)
            return True

    def register(self, connection: ClientConnection) -> None:
        with self._lock:
            if connection.virtual_ip not in self._reserved_ips:
                raise RuntimeError("virtual IP was not reserved")
            if connection.client_id not in self._claimed_ids:
                raise RuntimeError("client ID was not claimed")
            if connection.virtual_ip in self._by_ip:
                raise RuntimeError("virtual IP is already active")
            if connection.client_id in self._by_id:
                raise RuntimeError("client ID is already active")
            self._reserved_ips.remove(connection.virtual_ip)
            self._claimed_ids.remove(connection.client_id)
            self._by_ip[connection.virtual_ip] = connection
            self._by_id[connection.client_id] = connection

    def release_pending(
        self, virtual_ip: str | None, client_id: str | None
    ) -> None:
        with self._lock:
            if virtual_ip is not None:
                self._reserved_ips.discard(virtual_ip)
            if client_id is not None:
                self._claimed_ids.discard(client_id)

    def unregister(self, connection: ClientConnection) -> None:
        with self._lock:
            if self._by_id.get(connection.client_id) is connection:
                self._by_id.pop(connection.client_id, None)
            if self._by_ip.get(connection.virtual_ip) is connection:
                self._by_ip.pop(connection.virtual_ip, None)
            self._reserved_ips.discard(connection.virtual_ip)
            self._claimed_ids.discard(connection.client_id)

    def get_by_ip(self, virtual_ip: str) -> ClientConnection | None:
        with self._lock:
            return self._by_ip.get(virtual_ip)

    def snapshot(self) -> list[ClientConnection]:
        with self._lock:
            return list(self._by_id.values())

    def count(self) -> int:
        with self._lock:
            return len(self._by_id)


@dataclass
class ClientConnection:
    sock: socket.socket
    address: tuple[str, int]
    channel: CaesarChannel
    client_id: str
    virtual_ip: str
    connected_at: float = field(default_factory=time.time)
    bytes_received: int = 0
    bytes_sent: int = 0
    last_heartbeat_time: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        self.send_lock = threading.Lock()
        self.reassembler = Reassembler()
        self.closed = threading.Event()
        self.last_peer_alive = time.monotonic()

    def mark_peer_alive(self) -> None:
        self.last_peer_alive = time.monotonic()
        self.last_heartbeat_time = time.time()

    def send_message(
        self,
        msg_type: MessageType,
        payload: bytes = b"",
        session_id: int = 0,
    ) -> None:
        with self.send_lock:
            if self.closed.is_set():
                raise ConnectionError("client connection is closed")
            for message in make_messages(msg_type, payload, session_id):
                send_frame(self.sock, self.channel.encrypt(message.encode()))

    def close(self) -> None:
        if self.closed.is_set():
            return
        self.closed.set()
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass

    def status(self) -> dict[str, object]:
        return {
            "client_id": self.client_id,
            "real_ip": self.address[0],
            "real_port": self.address[1],
            "virtual_ip": self.virtual_ip,
            "connected_at": self.connected_at,
            "connected_seconds": round(time.time() - self.connected_at, 1),
            "bytes_received": self.bytes_received,
            "bytes_sent": self.bytes_sent,
            "last_heartbeat_time": self.last_heartbeat_time,
        }


@dataclass
class PortMappingEntry:
    client_id: str
    client_virtual_ip: str
    protocol: str
    source_ip: str
    source_port: int
    destination_ip: str
    destination_port: int
    session_id: int
    first_seen: float
    last_seen: float
    packet_count: int = 1


class PortMappingTable:
    def __init__(self) -> None:
        self._entries: dict[tuple[object, ...], PortMappingEntry] = {}
        self._lock = threading.Lock()

    def update(
        self, client_id: str, client_virtual_ip: str, flow: Flow, session_id: int
    ) -> None:
        key = (
            client_id,
            flow.protocol,
            flow.source_ip,
            flow.source_port,
            flow.destination_ip,
            flow.destination_port,
        )
        now = time.time()
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                self._entries[key] = PortMappingEntry(
                    client_id=client_id,
                    client_virtual_ip=client_virtual_ip,
                    protocol=flow.protocol_name,
                    source_ip=flow.source_ip,
                    source_port=flow.source_port,
                    destination_ip=flow.destination_ip,
                    destination_port=flow.destination_port,
                    session_id=session_id,
                    first_seen=now,
                    last_seen=now,
                )
            else:
                entry.last_seen = now
                entry.packet_count += 1
                entry.session_id = session_id

    def remove_client(self, client_id: str) -> int:
        with self._lock:
            keys = [
                key
                for key, entry in self._entries.items()
                if entry.client_id == client_id
            ]
            for key in keys:
                del self._entries[key]
            return len(keys)

    def expire_stale(self, max_age: float) -> int:
        cutoff = time.time() - max_age
        with self._lock:
            keys = [
                key
                for key, entry in self._entries.items()
                if entry.last_seen < cutoff
            ]
            for key in keys:
                del self._entries[key]
            return len(keys)

    def snapshot(self) -> list[PortMappingEntry]:
        with self._lock:
            return list(self._entries.values())

    def print_compact(self) -> None:
        entries = sorted(
            self.snapshot(),
            key=lambda entry: (entry.client_id, entry.first_seen),
        )
        now = time.time()
        print(f"[MAPPINGS] active flows: {len(entries)}")
        for entry in entries:
            print(
                "[MAPPINGS] "
                f"{entry.client_id}/{entry.client_virtual_ip} "
                f"{entry.protocol} "
                f"{entry.source_ip}:{entry.source_port} -> "
                f"{entry.destination_ip}:{entry.destination_port} "
                f"sid={entry.session_id} packets={entry.packet_count} "
                f"age={now - entry.first_seen:.0f}s "
                f"idle={now - entry.last_seen:.0f}s"
            )


class ServerNetworkManager:
    def __init__(self, tun_name: str, outbound_interface: str | None) -> None:
        self.tun_name = tun_name
        self.outbound_interface = outbound_interface
        self._added_rules: list[tuple[str | None, str, list[str]]] = []
        self._previous_ip_forward: str | None = None
        self._changed_ip_forward = False

    def _detect_outbound_interface(self) -> str:
        result = run_network_command(["ip", "-4", "route", "show", "default"])
        default_line = next(
            (line for line in result.stdout.splitlines() if line.strip()), ""
        )
        match = re.search(r"\bdev\s+(\S+)", default_line)
        if not match:
            raise RuntimeError(
                "could not determine the outbound interface; pass --outbound-interface"
            )
        return match.group(1)

    def _iptables_prefix(self, table: str | None) -> list[str]:
        prefix = ["iptables", "-w"]
        if table is not None:
            prefix.extend(["-t", table])
        return prefix

    def _add_rule(
        self, table: str | None, chain: str, rule: list[str]
    ) -> None:
        prefix = self._iptables_prefix(table)
        check = run_network_command(
            [*prefix, "-C", chain, *rule], check=False
        )
        if check.returncode == 0:
            return
        run_network_command([*prefix, "-A", chain, *rule])
        self._added_rules.append((table, chain, rule))

    def setup(self) -> str:
        outbound = self.outbound_interface or self._detect_outbound_interface()
        try:
            current = run_network_command(
                ["sysctl", "-n", "net.ipv4.ip_forward"]
            ).stdout.strip()
            self._previous_ip_forward = current
            if current != "1":
                run_network_command(
                    ["sysctl", "-w", "net.ipv4.ip_forward=1"]
                )
                self._changed_ip_forward = True

            self._add_rule(
                "nat",
                "POSTROUTING",
                [
                    "-s",
                    VPN_SUBNET,
                    "-o",
                    outbound,
                    "-j",
                    "MASQUERADE",
                ],
            )
            self._add_rule(
                None,
                "FORWARD",
                [
                    "-i",
                    self.tun_name,
                    "-o",
                    outbound,
                    "-s",
                    VPN_SUBNET,
                    "-j",
                    "ACCEPT",
                ],
            )
            self._add_rule(
                None,
                "FORWARD",
                [
                    "-i",
                    outbound,
                    "-o",
                    self.tun_name,
                    "-d",
                    VPN_SUBNET,
                    "-m",
                    "conntrack",
                    "--ctstate",
                    "ESTABLISHED,RELATED",
                    "-j",
                    "ACCEPT",
                ],
            )
            return outbound
        except Exception:
            self.cleanup()
            raise

    def cleanup(self) -> None:
        for table, chain, rule in reversed(self._added_rules):
            run_network_command(
                [*self._iptables_prefix(table), "-D", chain, *rule],
                check=False,
            )
        self._added_rules.clear()
        if self._changed_ip_forward and self._previous_ip_forward is not None:
            run_network_command(
                [
                    "sysctl",
                    "-w",
                    f"net.ipv4.ip_forward={self._previous_ip_forward}",
                ],
                check=False,
            )
            self._changed_ip_forward = False


class VPNServer:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.stop_event = threading.Event()
        self.manager = ClientManager()
        self.mappings = PortMappingTable()
        self.tun: TunDevice | None = None
        self.network: ServerNetworkManager | None = None
        self.listener: socket.socket | None = None
        self.status_listener: socket.socket | None = None
        self.tun_write_lock = threading.Lock()
        self._sockets: set[socket.socket] = set()
        self._sockets_lock = threading.Lock()
        self._threads: list[threading.Thread] = []
        self._cleanup_lock = threading.Lock()
        self._cleaned = False

    def _make_listener(self, port: int, backlog: int) -> socket.socket:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((self.args.bind, port))
        listener.listen(backlog)
        listener.settimeout(1.0)
        return listener

    def _start_thread(self, target: object, name: str) -> None:
        thread = threading.Thread(target=target, name=name, daemon=True)
        thread.start()
        self._threads.append(thread)

    def _track_socket(self, sock: socket.socket) -> None:
        with self._sockets_lock:
            self._sockets.add(sock)

    def _untrack_socket(self, sock: socket.socket) -> None:
        with self._sockets_lock:
            self._sockets.discard(sock)

    def run(self) -> None:
        try:
            self.tun = create_tun(self.args.tun_name)
            configure_tun(
                self.tun.name, SERVER_TUN_IP_CIDR, self.args.mtu
            )
            self.network = ServerNetworkManager(
                self.tun.name, self.args.outbound_interface
            )
            outbound = self.network.setup()
            print(
                f"[SERVER] {self.tun.name}={SERVER_TUN_IP_CIDR}; "
                f"forwarding/NAT outbound on {outbound}"
            )

            self.listener = self._make_listener(self.args.port, 100)
            self.status_listener = self._make_listener(
                self.args.status_port, 10
            )
            self._start_thread(self.tun_reader_loop, "tun-reader")
            self._start_thread(self.heartbeat_loop, "heartbeats")
            self._start_thread(self.status_api_loop, "status-api")
            self._start_thread(self.mapping_loop, "mapping-cleanup")

            print(
                f"[SERVER] VPN listening on {self.args.bind}:{self.args.port}; "
                f"status on {self.args.bind}:{self.args.status_port}"
            )
            while not self.stop_event.is_set():
                try:
                    sock, address = self.listener.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if self.stop_event.is_set():
                        break
                    raise
                self._track_socket(sock)
                thread = threading.Thread(
                    target=self.handle_client,
                    args=(sock, address),
                    name=f"client-{address[0]}:{address[1]}",
                    daemon=True,
                )
                thread.start()
                self._threads.append(thread)
        finally:
            self.cleanup()

    def handle_client(
        self, sock: socket.socket, address: tuple[str, int]
    ) -> None:
        virtual_ip: str | None = None
        claimed_client_id: str | None = None
        connection: ClientConnection | None = None
        registered = False

        def claim_client_id(client_id: str) -> bool:
            nonlocal claimed_client_id
            accepted = self.manager.claim_client_id(client_id)
            if accepted:
                claimed_client_id = client_id
            return accepted

        try:
            sock.settimeout(10.0)
            virtual_ip = self.manager.reserve_ip()
            channel, client_id = server_handshake(
                sock,
                virtual_ip,
                self.args.psk,
                client_id_validator=claim_client_id,
            )
            sock.settimeout(None)
            connection = ClientConnection(
                sock=sock,
                address=address,
                channel=channel,
                client_id=client_id,
                virtual_ip=virtual_ip,
            )
            self.manager.register(connection)
            registered = True
            print(
                f"[SERVER] connected id={client_id} "
                f"real={address[0]}:{address[1]} virtual={virtual_ip} "
                f"active={self.manager.count()}"
            )

            while (
                not self.stop_event.is_set()
                and not connection.closed.is_set()
            ):
                encrypted = recv_frame(sock)
                message = Message.decode(channel.decrypt(encrypted))
                reassembled = connection.reassembler.add(message)
                if reassembled is None:
                    continue
                msg_type, session_id, payload = reassembled
                connection.last_peer_alive = time.monotonic()

                if msg_type == MessageType.DATA:
                    connection.bytes_received += len(payload)
                    try:
                        flow = parse_ipv4(payload)
                    except ValueError as exc:
                        print(
                            f"[SERVER] dropped malformed packet from "
                            f"{connection.client_id}: {exc}"
                        )
                        continue
                    if flow.source_ip != connection.virtual_ip:
                        print(
                            f"[SERVER] dropped spoofed source {flow.source_ip} "
                            f"from {connection.client_id}"
                        )
                        continue
                    if flow.protocol in (6, 17):
                        self.mappings.update(
                            connection.client_id,
                            connection.virtual_ip,
                            flow,
                            session_id,
                        )
                    assert self.tun is not None
                    with self.tun_write_lock:
                        os.write(self.tun.fd, payload)
                elif msg_type == MessageType.HEARTBEAT:
                    connection.mark_peer_alive()
                    connection.send_message(MessageType.HEARTBEAT_ACK)
                elif msg_type == MessageType.HEARTBEAT_ACK:
                    connection.mark_peer_alive()
                elif msg_type == MessageType.CLOSE:
                    break
        except Exception as exc:
            if not self.stop_event.is_set():
                print(f"[SERVER] connection {address} ended: {exc}")
        finally:
            if connection is not None:
                connection.close()
                self.mappings.remove_client(connection.client_id)
                self.manager.unregister(connection)
            else:
                self.manager.release_pending(
                    virtual_ip, claimed_client_id
                )
                try:
                    sock.close()
                except OSError:
                    pass
            self._untrack_socket(sock)
            if registered and connection is not None:
                print(
                    f"[SERVER] disconnected id={connection.client_id} "
                    f"virtual={connection.virtual_ip} "
                    f"active={self.manager.count()}"
                )

    def tun_reader_loop(self) -> None:
        assert self.tun is not None
        while not self.stop_event.is_set():
            try:
                readable, _, _ = select.select(
                    [self.tun.fd], [], [], 1.0
                )
                if not readable:
                    continue
                packet = os.read(self.tun.fd, 65535)
            except (OSError, ValueError):
                break
            try:
                flow = parse_ipv4(packet)
            except ValueError as exc:
                print(f"[SERVER] ignored malformed TUN packet: {exc}")
                continue
            connection = self.manager.get_by_ip(flow.destination_ip)
            if connection is None:
                continue
            try:
                connection.send_message(
                    MessageType.DATA, packet, flow.session_id
                )
                connection.bytes_sent += len(packet)
            except (ConnectionError, OSError):
                connection.close()

    def heartbeat_loop(self) -> None:
        while not self.stop_event.wait(HEARTBEAT_INTERVAL):
            now = time.monotonic()
            for connection in self.manager.snapshot():
                if now - connection.last_peer_alive > HEARTBEAT_TIMEOUT:
                    print(
                        f"[SERVER] heartbeat timeout for "
                        f"{connection.client_id}"
                    )
                    connection.close()
                    continue
                try:
                    connection.send_message(MessageType.HEARTBEAT)
                except (ConnectionError, OSError):
                    connection.close()

    def status_api_loop(self) -> None:
        assert self.status_listener is not None
        while not self.stop_event.is_set():
            try:
                sock, _ = self.status_listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with sock:
                clients = [
                    connection.status()
                    for connection in self.manager.snapshot()
                ]
                payload = {
                    "ok": True,
                    "connected_clients": len(clients),
                    "vpn_port": self.args.port,
                    "clients": clients,
                }
                try:
                    sock.sendall(
                        json.dumps(payload, separators=(",", ":")).encode(
                            "utf-8"
                        )
                        + b"\n"
                    )
                except OSError:
                    pass

    def mapping_loop(self) -> None:
        while not self.stop_event.wait(self.args.mapping_interval):
            removed = self.mappings.expire_stale(
                self.args.mapping_timeout
            )
            if removed:
                print(f"[MAPPINGS] expired {removed} stale flow(s)")
            if self.args.show_mappings:
                self.mappings.print_compact()

    def request_stop(self) -> None:
        if self.stop_event.is_set():
            return
        self.stop_event.set()
        for listener in (self.listener, self.status_listener):
            if listener is not None:
                try:
                    listener.close()
                except OSError:
                    pass
        with self._sockets_lock:
            sockets = list(self._sockets)
        for sock in sockets:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        for connection in self.manager.snapshot():
            connection.close()
        if self.tun is not None:
            self.tun.close()

    def cleanup(self) -> None:
        with self._cleanup_lock:
            if self._cleaned:
                return
            self._cleaned = True
        self.request_stop()
        current = threading.current_thread()
        for thread in self._threads:
            if thread is not current:
                thread.join(timeout=1.0)
        for connection in self.manager.snapshot():
            self.mappings.remove_client(connection.client_id)
            self.manager.unregister(connection)
        if self.network is not None:
            try:
                self.network.cleanup()
            except Exception as exc:
                print(f"[SERVER] network cleanup warning: {exc}")
        print("[SERVER] shutdown complete")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Layer-3 TUN VPN server")
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--status-port", type=int, default=DEFAULT_STATUS_PORT)
    parser.add_argument("--psk", default=DEFAULT_PSK)
    parser.add_argument("--tun-name", default="tun0")
    parser.add_argument("--mtu", type=int, default=DEFAULT_TUN_MTU)
    parser.add_argument(
        "--outbound-interface",
        help="physical interface for forwarding; default is auto-detected",
    )
    parser.add_argument(
        "--show-mappings",
        action="store_true",
        help="print the application flow table periodically",
    )
    parser.add_argument("--mapping-interval", type=float, default=20.0)
    parser.add_argument("--mapping-timeout", type=float, default=120.0)
    args = parser.parse_args()
    if args.mapping_interval <= 0 or args.mapping_timeout <= 0:
        parser.error("mapping intervals must be positive")
    return args


def main() -> None:
    args = parse_args()
    server = VPNServer(args)
    signal.signal(signal.SIGINT, lambda _signum, _frame: server.request_stop())
    signal.signal(signal.SIGTERM, lambda _signum, _frame: server.request_stop())
    try:
        server.run()
    except Exception as exc:
        print(f"[SERVER] fatal error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
