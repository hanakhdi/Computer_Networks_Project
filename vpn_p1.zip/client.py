from __future__ import annotations

import argparse
import json
import os
import select
import signal
import socket
import sys
import threading
import time

from common import (
    DEFAULT_LB_PORT,
    DEFAULT_PORT,
    DEFAULT_PSK,
    DEFAULT_TUN_MTU,
    HEARTBEAT_INTERVAL,
    HEARTBEAT_TIMEOUT,
    CaesarChannel,
    Message,
    MessageType,
    Reassembler,
    RouteManager,
    TunDevice,
    client_handshake,
    configure_tun,
    create_tun,
    make_messages,
    parse_ipv4,
    recv_frame,
    recv_line,
    send_frame,
)


class VPNClient:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.stop_event = threading.Event()
        self.sock: socket.socket | None = None
        self.channel: CaesarChannel | None = None
        self.tun: TunDevice | None = None
        self.route_manager: RouteManager | None = None
        self.virtual_ip: str | None = None
        self.send_lock = threading.Lock()
        self.reassembler = Reassembler()
        self.last_peer_alive = time.monotonic()
        self._threads: list[threading.Thread] = []
        self._cleanup_lock = threading.Lock()
        self._cleaned = False

    def resolve_server(self) -> tuple[str, int]:
        if not self.args.load_balancer:
            return self.args.server_ip, self.args.port

        print(
            f"[CLIENT] asking load balancer "
            f"{self.args.load_balancer}:{self.args.lb_port}"
        )
        request = json.dumps(
            {"client_id": self.args.client_id}, separators=(",", ":")
        ).encode("utf-8")
        with socket.create_connection(
            (self.args.load_balancer, self.args.lb_port), timeout=5.0
        ) as lb_sock:
            lb_sock.sendall(request + b"\n")
            response = recv_line(lb_sock)
        data = json.loads(response.decode("utf-8"))
        if not data.get("ok"):
            raise RuntimeError(
                f"load balancer rejected request: {data.get('error')}"
            )
        return str(data["server_ip"]), int(data["server_port"])

    def send_message(
        self,
        msg_type: MessageType,
        payload: bytes = b"",
        session_id: int = 0,
    ) -> None:
        if self.sock is None or self.channel is None:
            raise ConnectionError("VPN channel is not established")
        with self.send_lock:
            for message in make_messages(msg_type, payload, session_id):
                send_frame(
                    self.sock, self.channel.encrypt(message.encode())
                )

    def _start_thread(self, target: object, name: str) -> None:
        thread = threading.Thread(target=target, name=name, daemon=True)
        thread.start()
        self._threads.append(thread)

    def run(self) -> None:
        server_host, server_port = self.resolve_server()
        server_ip = socket.gethostbyname(server_host)
        print(f"[CLIENT] connecting to {server_ip}:{server_port}")
        try:
            self.sock = socket.create_connection(
                (server_ip, server_port), timeout=10.0
            )
            self.channel, self.virtual_ip = client_handshake(
                self.sock, self.args.client_id, self.args.psk
            )
            self.sock.settimeout(None)
            print(
                f"[CLIENT] authenticated; assigned {self.virtual_ip}"
            )

            self.tun = create_tun(self.args.tun_name)
            configure_tun(
                self.tun.name,
                f"{self.virtual_ip}/24",
                self.args.mtu,
            )
            self.route_manager = RouteManager(self.tun.name)

            if self.args.full_tunnel:
                self.route_manager.enable_full_tunnel(server_ip)
                print(
                    "[CLIENT] full tunnel enabled with two /1 routes; "
                    "the VPN server keeps a physical /32 route"
                )
            else:
                for network in self.args.route:
                    self.route_manager.add_tunnel_route(network)
                    print(f"[CLIENT] tunnel route added: {network}")

            self._start_thread(self.tun_to_server, "tun-to-server")
            self._start_thread(self.server_to_tun, "server-to-tun")
            self._start_thread(self.heartbeat_loop, "heartbeats")

            while not self.stop_event.wait(0.5):
                pass
        finally:
            self.cleanup()

    def tun_to_server(self) -> None:
        assert self.tun is not None
        while not self.stop_event.is_set():
            try:
                readable, _, _ = select.select(
                    [self.tun.fd], [], [], 1.0
                )
                if not readable:
                    continue
                packet = os.read(self.tun.fd, 65535)
            except (OSError, ValueError):
                break
            try:
                flow = parse_ipv4(packet)
                self.send_message(
                    MessageType.DATA, packet, flow.session_id
                )
            except ValueError as exc:
                print(f"[CLIENT] ignored malformed TUN packet: {exc}")
            except (ConnectionError, OSError) as exc:
                if not self.stop_event.is_set():
                    print(f"[CLIENT] send path stopped: {exc}")
                self.request_stop()
                break

    def server_to_tun(self) -> None:
        assert self.sock is not None
        assert self.channel is not None
        assert self.tun is not None
        while not self.stop_event.is_set():
            try:
                encrypted = recv_frame(self.sock)
                message = Message.decode(self.channel.decrypt(encrypted))
                reassembled = self.reassembler.add(message)
                if reassembled is None:
                    continue
                msg_type, _session_id, payload = reassembled
                self.last_peer_alive = time.monotonic()

                if msg_type == MessageType.DATA:
                    flow = parse_ipv4(payload)
                    if (
                        self.virtual_ip is not None
                        and flow.destination_ip != self.virtual_ip
                    ):
                        print(
                            f"[CLIENT] dropped packet for unexpected "
                            f"destination {flow.destination_ip}"
                        )
                        continue
                    os.write(self.tun.fd, payload)
                elif msg_type == MessageType.HEARTBEAT:
                    self.send_message(MessageType.HEARTBEAT_ACK)
                elif msg_type == MessageType.CLOSE:
                    print("[CLIENT] server requested connection close")
                    self.request_stop()
                    break
            except Exception as exc:
                if not self.stop_event.is_set():
                    print(f"[CLIENT] receive path stopped: {exc}")
                self.request_stop()
                break

    def heartbeat_loop(self) -> None:
        while not self.stop_event.wait(HEARTBEAT_INTERVAL):
            if (
                time.monotonic() - self.last_peer_alive
                > HEARTBEAT_TIMEOUT
            ):
                print("[CLIENT] server heartbeat timeout")
                self.request_stop()
                return
            try:
                self.send_message(MessageType.HEARTBEAT)
            except (ConnectionError, OSError):
                self.request_stop()
                return

    def request_stop(self) -> None:
        if self.stop_event.is_set():
            return
        self.stop_event.set()
        if self.sock is not None:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
        if self.tun is not None:
            self.tun.close()

    def cleanup(self) -> None:
        with self._cleanup_lock:
            if self._cleaned:
                return
            self._cleaned = True
        self.request_stop()
        current = threading.current_thread()
        for thread in self._threads:
            if thread is not current:
                thread.join(timeout=1.0)
        if self.route_manager is not None:
            self.route_manager.cleanup()
        print("[CLIENT] routes, TUN device, and socket cleaned up")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Layer-3 TUN VPN client")
    parser.add_argument("--server-ip", default="10.10.10.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--client-id", default=socket.gethostname())
    parser.add_argument("--psk", default=DEFAULT_PSK)
    parser.add_argument("--tun-name", default="tun0")
    parser.add_argument("--mtu", type=int, default=DEFAULT_TUN_MTU)
    parser.add_argument(
        "--route",
        action="append",
        default=[],
        help="IPv4 network routed through TUN; may be repeated",
    )
    parser.add_argument("--full-tunnel", action="store_true")
    parser.add_argument("--load-balancer", help="load balancer IP or hostname")
    parser.add_argument("--lb-port", type=int, default=DEFAULT_LB_PORT)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    client = VPNClient(args)
    signal.signal(signal.SIGINT, lambda _signum, _frame: client.request_stop())
    signal.signal(signal.SIGTERM, lambda _signum, _frame: client.request_stop())
    try:
        client.run()
    except Exception as exc:
        print(f"[CLIENT] fatal error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
