#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname -- "$0")"

exec sudo python3 server.py \
  --bind 0.0.0.0 \
  --port 9000 \
  --status-port 9200 \
  --psk "${VPN_PSK:-classroom-secret}" \
  --tun-name tun0 \
  --show-mappings
