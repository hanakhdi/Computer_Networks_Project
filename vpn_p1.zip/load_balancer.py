from __future__ import annotations

import argparse
import json
import signal
import socket
import threading
from dataclasses import dataclass

from common import DEFAULT_LB_PORT, recv_line


@dataclass(frozen=True)
class Backend:
    ip: str
    vpn_port: int
    status_port: int


class LoadBalancer:
    def __init__(self, bind: str, port: int, backends: list[Backend]) -> None:
        self.bind = bind
        self.port = port
        self.backends = backends
        self.stop_event = threading.Event()
        self.listener: socket.socket | None = None

    def query_backend(self, backend: Backend) -> int:
        with socket.create_connection(
            (backend.ip, backend.status_port), timeout=1.5
        ) as sock:
            response = recv_line(sock)
        status = json.loads(response.decode("utf-8"))
        if not status.get("ok"):
            raise RuntimeError("backend returned an unhealthy status")
        return int(status["connected_clients"])

    def choose_backend(self) -> Backend:
        candidates: list[tuple[int, Backend]] = []
        for backend in self.backends:
            try:
                candidates.append(
                    (self.query_backend(backend), backend)
                )
            except Exception as exc:
                print(
                    f"[LB] backend {backend.ip}:{backend.status_port} "
                    f"is unavailable: {exc}"
                )
        if not candidates:
            raise RuntimeError("no healthy VPN server is available")
        return min(candidates, key=lambda candidate: candidate[0])[1]

    def handle_client(
        self, sock: socket.socket, address: tuple[str, int]
    ) -> None:
        with sock:
            try:
                request = json.loads(recv_line(sock).decode("utf-8"))
                client_id = str(request.get("client_id", "unknown"))
                backend = self.choose_backend()
                response = {
                    "ok": True,
                    "server_ip": backend.ip,
                    "server_port": backend.vpn_port,
                }
                print(
                    f"[LB] client={client_id} from {address[0]} "
                    f"selected {backend.ip}:{backend.vpn_port}"
                )
            except Exception as exc:
                response = {"ok": False, "error": str(exc)}
            try:
                sock.sendall(
                    json.dumps(response, separators=(",", ":")).encode(
                        "utf-8"
                    )
                    + b"\n"
                )
            except OSError:
                pass

    def run(self) -> None:
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(
            socket.SOL_SOCKET, socket.SO_REUSEADDR, 1
        )
        self.listener.bind((self.bind, self.port))
        self.listener.listen(100)
        self.listener.settimeout(1.0)
        print(f"[LB] listening on {self.bind}:{self.port}")
        try:
            while not self.stop_event.is_set():
                try:
                    sock, address = self.listener.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if self.stop_event.is_set():
                        break
                    raise
                threading.Thread(
                    target=self.handle_client,
                    args=(sock, address),
                    daemon=True,
                ).start()
        finally:
            self.request_stop()

    def request_stop(self) -> None:
        self.stop_event.set()
        if self.listener is not None:
            try:
                self.listener.close()
            except OSError:
                pass


def parse_backend(value: str) -> Backend:
    parts = value.rsplit(":", 2)
    if len(parts) != 3:
        raise argparse.ArgumentTypeError(
            "backend must be IP_OR_HOST:VPN_PORT:STATUS_PORT"
        )
    try:
        vpn_port = int(parts[1])
        status_port = int(parts[2])
    except ValueError as exc:
        raise argparse.ArgumentTypeError("backend ports must be integers") from exc
    if not 1 <= vpn_port <= 65535 or not 1 <= status_port <= 65535:
        raise argparse.ArgumentTypeError("backend ports must be 1 to 65535")
    return Backend(parts[0], vpn_port, status_port)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Least-connections VPN server discovery"
    )
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=DEFAULT_LB_PORT)
    parser.add_argument(
        "--backend",
        action="append",
        type=parse_backend,
        required=True,
        help="IP_OR_HOST:VPN_PORT:STATUS_PORT",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    load_balancer = LoadBalancer(args.bind, args.port, args.backend)
    signal.signal(
        signal.SIGINT,
        lambda _signum, _frame: load_balancer.request_stop(),
    )
    signal.signal(
        signal.SIGTERM,
        lambda _signum, _frame: load_balancer.request_stop(),
    )
    load_balancer.run()


if __name__ == "__main__":
    main()

