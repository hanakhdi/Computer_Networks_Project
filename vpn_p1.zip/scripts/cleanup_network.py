from __future__ import annotations

import argparse
import ipaddress
import os
import subprocess
import sys


RULE_COMMENT = "vpn-phase1-target-block"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Remove the target firewall rule added by target_setup.py"
    )
    parser.add_argument("--blocked-client-ip", required=True)
    parser.add_argument("--interface", required=True)
    args = parser.parse_args()

    try:
        if os.name != "posix":
            raise RuntimeError("this script supports Linux only")
        if os.geteuid() != 0:
            raise RuntimeError("run this script with sudo")
        address = str(ipaddress.IPv4Address(args.blocked_client_ip))
        rule = [
            "-i",
            args.interface,
            "-s",
            address,
            "-m",
            "comment",
            "--comment",
            RULE_COMMENT,
            "-j",
            "DROP",
        ]
        check = subprocess.run(
            ["iptables", "-w", "-C", "INPUT", *rule],
            check=False,
            text=True,
            capture_output=True,
        )
        if check.returncode == 1:
            print("[TARGET] matching firewall rule is already absent")
            return
        if check.returncode != 0:
            detail = check.stderr.strip() or "could not inspect iptables rules"
            raise RuntimeError(detail)
        removed = subprocess.run(
            ["iptables", "-w", "-D", "INPUT", *rule],
            check=False,
            text=True,
            capture_output=True,
        )
        if removed.returncode != 0:
            detail = removed.stderr.strip() or "unknown iptables error"
            raise RuntimeError(f"could not remove firewall rule: {detail}")
        print("[TARGET] firewall rule removed")
    except FileNotFoundError as exc:
        print("[TARGET] error: iptables is not installed", file=sys.stderr)
        raise SystemExit(1) from exc
    except Exception as exc:
        print(f"[TARGET] error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
