#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname -- "$0")"

server_ip="${1:-${VPN_SERVER_IP:-10.206.50.158}}"

exec sudo python3 client.py \
  --server-ip "$server_ip" \
  --port 9000 \
  --psk "${VPN_PSK:-classroom-secret}" \
  --tun-name tun0 \
  --full-tunnel
